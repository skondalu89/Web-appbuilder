///////////////////////////////////////////////////////////////////////////
// Copyright © Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////
var southCarolinaCounties,dialog;
var highlightSymbol;
var graphic;
var currentwidget = this;
define([
  'dojo/_base/declare',
  'dojo/_base/html',
  'jimu/BaseWidget',
  'jimu/dijit/Filter',
  "esri/map",
  "esri/layers/ArcGISDynamicMapServiceLayer",
  "esri/tasks/QueryTask",
  "esri/tasks/query",
  "esri/symbols/SimpleMarkerSymbol",
  "esri/InfoTemplate",
  "dojo/_base/Color",
  "dojo/dom",
  "esri/layers/FeatureLayer",
  "esri/symbols/SimpleFillSymbol", 
  "esri/symbols/SimpleLineSymbol",
  "esri/renderers/SimpleRenderer",
  "dojo/on",
  "esri/graphic",
  "esri/lang",
  "esri/Color",
  "dojo/number",
 "dojo/dom-style",
  "dijit/TooltipDialog", 
  "dijit/popup",
  "dojo/domReady!"
],
  function (declare, html, BaseWidget, Filter,Map,
    ArcGISDynamicMapServiceLayer, 
    QueryTask, Query, SimpleMarkerSymbol,
    InfoTemplate, Color, dom, FeatureLayer,
    SimpleFillSymbol, SimpleLineSymbol,
    SimpleRenderer,on, Graphic, esriLang,
    Color, number, domStyle,
    TooltipDialog, dijitPopup) {

    return declare([BaseWidget], {
       name: 'FilterDemo',
      //baseClass: 'jimu-widget-filter-demo',

      postCreate: function () {
        var currentwidget = this;
         var layer = new ArcGISDynamicMapServiceLayer(
          "http://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Specialty/ESRI_StatesCitiesRivers_USA/MapServer");
          this.map.addLayer(layer);
    southCarolinaCounties = new FeatureLayer("https://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Demographics/ESRI_Census_USA/MapServer/3", {
          mode: FeatureLayer.MODE_SNAPSHOT,
          outFields: ["NAME", "POP2000", "POP2007", "POP00_SQMI", "POP07_SQMI"]
        });
        southCarolinaCounties.setDefinitionExpression("STATE_NAME = 'South Carolina'");

        var symbol = new SimpleFillSymbol(
          SimpleFillSymbol.STYLE_SOLID,
          new SimpleLineSymbol(
            SimpleLineSymbol.STYLE_SOLID,
            new Color([255,255,255,0.35]),
            1
          ),
          new Color([125,125,125,0.35])
        );
        southCarolinaCounties.setRenderer(new SimpleRenderer(symbol));
        this.map.addLayer(southCarolinaCounties);
        this.map.infoWindow.resize(245,125);

        dialog = new TooltipDialog({
          id: "tooltipDialog",
          style: "position: absolute; width: 250px; font: normal normal normal 10pt Helvetica;z-index:100"
        });
        dialog.startup();

        var highlightSymbol = new SimpleFillSymbol(
          SimpleFillSymbol.STYLE_SOLID,
          new SimpleLineSymbol(
            SimpleLineSymbol.STYLE_SOLID,
            new Color([255,0,0]), 3
          ),
          new Color([125,125,125,0.35])
        );

        //close the dialog when the mouse leaves the highlight graphic
        this.map.graphics.enableMouseEvents();
        //this.map.graphics.on("mouse-out", closeDialog);

        this.map.on("load", function(){
          alert("Map Load here");
          this._map.graphics.enableMouseEvents();
          this._map.graphics.on("mouse-out", closeDialog);

        })

        //listen for when the onMouseOver event fires on the countiesGraphicsLayer
        //when fired, create a new graphic with the geometry from the event.graphic and add it to the maps graphics layer
        southCarolinaCounties.on("mouse-over", function(evt){
          var t = "<b>${NAME}</b><hr><b>2000 Population: </b>${POP2000:NumberFormat}<br>"
            + "<b>2000 Population per Sq. Mi.: </b>${POP00_SQMI:NumberFormat}<br>"
            + "<b>2007 Population: </b>${POP2007:NumberFormat}<br>"
            + "<b>2007 Population per Sq. Mi.: </b>${POP07_SQMI:NumberFormat}";

          var content = esriLang.substitute(evt.graphic.attributes,t);
          var highlightGraphic = new Graphic(evt.graphic.geometry,highlightSymbol);
          
          this._map.graphics.add(highlightGraphic);

          dialog.setContent(content);

          domStyle.set(dialog.domNode, "opacity", 0.85);
          dijitPopup.open({
            popup: dialog,
            x: evt.pageX,
            y: evt.pageY
          });
        });

        function closeDialog() {
          this._map.graphics.clear();
          dijitPopup.close(dialog);
        }
        
      },

      startup: function () {
        this.inherited(arguments);
        //this.filter.startup();
      },

      resize: function () {
        this.filter.autoUpdateMode();
      },

      _onBtnUpateFilterClicked: function () {
       
       // var featureLayer = new FeatureLayer("https://services.arcgis.com/V6ZHFr6zdgNZuVG0/arcgis/rest/services/Landscape_Trees/FeatureServer/0");
       var currentwidget = this;
       queryTask = new QueryTask("http://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Specialty/ESRI_StatesCitiesRivers_USA/MapServer/0");

       //initialize query
       query = new Query();
       query.returnGeometry = false;
       //query.outFields = ["CITY_NAME", "STATE_NAME", "POP1990"];
     
       //initialize InfoTemplate
       infoTemplate = new InfoTemplate("${CITY_NAME}", "Name : ${CITY_NAME}<br/> State : ${STATE_NAME}<br />Population : ${POP1990}");
     
      
       symbol = new SimpleMarkerSymbol();
       symbol.setStyle(SimpleMarkerSymbol.STYLE_CIRCLE);
       symbol.setSize(30);
       symbol.setColor(new Color([255,255,0,0.5]));
     
       //write "Get Details" button's click event
       //(dom.byId("runQuery"), "click", executeQueryTask);
        /*html.addClass(this.filterParameters.domNode, 'hidden');
        html.removeClass(this.filter.domNode, 'hidden');*/
        query.where = "1=1";
        query.outFields = ["*"];
        queryTask.execute(query);
       
        queryTask.on("complete", function (featureset) {
        //dojo.connect(queryTask,"onComplete", function(featureset)
        //{
          currentwidget.map.graphics.clear();
                  //Performance enhancer - assign featureSet array to a single variable.
          var resultFeatures = featureset.featureSet.features;
          
        
          //Loop through each feature returned
          for (var i=0, il=resultFeatures.length; i<il; i++) {
            //Get the current feature from the featureSet.
            //Feature is a graphic
            var graphic = resultFeatures[i];
            graphic.setSymbol(symbol);
        
            //Set the infoTemplate.
            graphic.setInfoTemplate(infoTemplate);
        
            //Add graphic to the map graphics layer.
            currentwidget.map.graphics.add(graphic);
            //this.map.graphics.add(graphic);
          }
        });
       //queryTask.execute(Statequery);





       
      }
      

  
    });
    
  });