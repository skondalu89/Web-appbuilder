define([
  'dojo/_base/declare', "jimu/BaseWidget","dojo/dom","dojo",
  'dojo/_base/array',
  'dojo/_base/Color',
  'dojo/_base/lang',
  'dojo/_base/json',
  'dojo/aspect',
  'dojo/dom',
  'dojo/dom-attr',
  'dojo/dom-class',
  'dojo/dom-construct',
  'dojo/dom-style',
  'dojo/number',
  'dojo/on',
  "dojo/keys",
  'dojo/query',
  'dojox/lang/functional',
  'dijit/_TemplatedMixin',
  'dijit/_WidgetBase',
  'dijit/_WidgetsInTemplateMixin',
  'dijit/form/HorizontalRule',
  'dijit/form/HorizontalRuleLabels',
  'esri/config',
  'esri/geometry/Extent',
  'esri/geometry/Point',
  'esri/geometry/Polygon',
  'esri/geometry/Polyline',
  'esri/geometry/scaleUtils',
  'esri/graphic',
  'esri/renderers/SimpleRenderer',
  'esri/request',
  'esri/symbols/CartographicLineSymbol',
  'esri/symbols/Font',
  'esri/symbols/SimpleFillSymbol',
  'esri/symbols/SimpleLineSymbol',
  'esri/symbols/SimpleMarkerSymbol',
  'esri/symbols/PictureMarkerSymbol',
  'esri/symbols/PictureFillSymbol',
  'esri/symbols/TextSymbol',
  'esri/tasks/LengthsParameters',
  'esri/tasks/PrintParameters',
  'esri/tasks/PrintTask',
  "esri/tasks/LegendLayer",
  'esri/tasks/PrintTemplate',
  'esri/units', 'dojo/topic',
 'dojo/text!./PrintResult.html',
 "jimu/dijit/Message",
  "dojo/_base/window",
  'dijit/form/Button',
  'dijit/form/CheckBox',
  'dijit/form/DropDownButton',
  'dijit/form/Form',
  'dijit/form/HorizontalSlider',
  'dijit/form/NumberTextBox',
  'dijit/form/RadioButton',
  'dijit/form/Select',
  'dijit/form/ValidationTextBox',
  'dijit/ProgressBar',
  'dijit/TooltipDialog',
  "dojo/domReady!"
], function (
      declare, BaseWidget,dom,dojo,
      array,
      Color,
      lang,
      dojoJSON,
      aspect,
      dom,
      domAttr,
      domClass,
      domConstruct,
      domStyle,
      number,
      on,
      keys,
      query,
      functional,
      _TemplatedMixin,
      _WidgetBase,
      _WidgetsInTemplateMixin,
      HorizontalRule,
      HorizontalRuleLabels,
      esriConfig,
      Extent,
      Point,
      Polygon,
      Polyline,
      scaleUtils,
      Graphic,
      SimpleRenderer,
      esriRequest,
      CartographicLineSymbol,
      Font,
      SimpleFillSymbol,
      SimpleLineSymbol,
      SimpleMarkerSymbol,
      PictureMarkerSymbol,
      PictureFillSymbol,
      TextSymbol,
      LengthsParameters,
      PrintParameters,
      PrintTask,
      LegendLayer,
      PrintTemplate,
      Units, topic
      , printResultTemplate, Message, win
      ) {

      // Main print dijit
    var PrintDijit = declare([BaseWidget,_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
       
        baseClass: 'jimu-widget-Printwidget',
        map: null,
        count: 1,
        results: [],
        authorText: null,
        copyrightText: null,
        defaultTitle: null,
        defaultFormat: null,
        defaultLayout: null,
        defaultDpi: 90,
        noTitleBlockPrefix: null,
        layoutParams: null,
        mapSheetParams: {},
        relativeScale: null,
        titleBlock: true,
        relativeScaleFactor: null,
        scalePrecision: null,
        scaleUnitValue: null,
        scalebarParams: null,
        isLayout: false,
        mapScales: null,
        outWkid: null,
        showLayout: true,
        showOpacitySlider: true,
        domIdPrefix: null,
        isDocked: false,
        suspendExtentHandler: false,
        dragSwipeHandlers: [],
        panZoomHandlers: [],
        resizeDelay: 100,
        widgetOpacityOver: 1.0,
        widgetOpacityOut: 0.9,
        countno: null,
        isSliderChange: false,
        maptype: '',
        cleargraphics:null,
        scaleLabelMaps:[],
        pdfIcon: null,
        imageIcon:null,
        serviceURL: null,
        printTask: null,
        async: false,
        mapUnitsToMeters: {},
        layoutLayerId: 'layoutGraphics',  // Make sure the layoutLayerId doesn't start with 'graphicsLayer' or it will be printed.
        WidgetName: "Print Widget",

        constructor: function (options, srcNodeRef) {
            var printOptions = options.config;

            options = declare.safeMixin(options || {}, printOptions);
            declare.safeMixin(this, options);
            this.domNode = srcNodeRef;
          
        },

        postCreate: function () {
            this.inherited(arguments);
           
            var currentWidget = this;
            currentWidget.scaleLabelMaps = currentWidget.config.Scalebar;
           
            currentWidget.pdfIcon = require.toUrl(currentWidget.config.PdfIcon);
            currentWidget.imageIcon = require.toUrl(currentWidget.config.Imageicon);

            domStyle.set(dom.byId(currentWidget.scaleSliderDiv), "display", "none");
         
            var printParams = {
                async: this.async
            };
            var _handleAs = 'json';
            this.printTask = new PrintTask(this.serviceURL, printParams);
            this.printparams = new PrintParameters();
            this.printparams.map = this.map;
            this.printparams.outSpatialReference = this.map.spatialReference;
            this.authorNode.set('value', this.defaultAuthor);
            this.copyrightNode.set('value', this.defaultCopyright);
            this._getPrintTaskInfo(_handleAs);
        
            var dpival = this.dpiValues;
            var option = '';

            array.forEach(dpival, function (item) {
                var select = dojo.byId(currentWidget.dpiQualityDijit);
                var opt = document.createElement("option");
                opt.value = item;
                opt.innerHTML = item;
                select.add(opt);
            });
            if (this.printTask._createOperationalLayers) {
                aspect.after(this.printTask, '_createOperationalLayers', lang.hitch(this, '_excludeInvalidLegend'));
            }
            on.once(this.map, "extent-change", lang.hitch(this, this.mapExtentChanged));
            currentWidget.mapExtentChanged('', '', '', '');

        },

       


        _getPrintTaskInfo: function (handle) {
            var currentWidget = this;
            esriRequest({
                url: this.serviceURL,
                content: {
                    f: "json"
                },
                callbackParamName: "callback",
                handleAs: handle || "json",
                timeout: 360000
            }).then(
              lang.hitch(this, '_handlePrintInfo'),
              lang.hitch(this, '_handleError')
            ).always(lang.hitch(this, function () {
            }));
            on(win.doc, ".printAllTable .removeImage:click", function (e) {
                // var rowcnt = $(this).closest('tr')[0].id;
                var rowcnt = e.path[2].id;
                if (dojo.query('.printAllTable >tbody >tr').length == 1)
                    currentWidget.count = 1;
                else if (rowcnt == currentWidget.count - 1)
                    currentWidget.count--;
                var selected = e.path[2].innerText;
                var count = dojo.query(".printAllTable >tbody >tr").length;
                for (var x = 0; x < dojo.query(".printAllTable >tbody >tr").length; x++) {
                    var compare = dojo.query(".printAllTable >tbody >tr")[x].innerText;
                    if (selected == compare) {
                        dojo.query(".printAllTable >tbody >tr")[x].remove();
                    }

                }
            })
        },
        _excludeInvalidLegend: function (opLayers) {
            if (this.printTask.allLayerslegend) {
                var legendArray = this.printTask.allLayerslegend;
                var arr = [];
                for (var i = 0; i < legendArray.length; i++) {
                    var layer = this.map.getLayer(legendArray[i].id);
                    if ((layer && layer.declaredClass &&
                        layer.declaredClass !== 'esri.layers.GraphicsLayer') &&
                        (!layer.renderer || (layer.renderer && !layer.renderer.hasVisualVariables()))) {
                        arr.push(legendArray[i]);
                    }
                }
                this.printTask.allLayerslegend = arr;
            }
            return opLayers;
        },
        _makeLayerForGraphic: function (gra, lyrName, geomType, isText) {
            if (isText) {
                // Text won't show up in the Legend, so we don't need a renderer to carry the label
                // For text, we do need the symbol in the "features" array.
                return {
                    layerDefinition: {
                        name: lyrName,
                        geometryType: geomType
                    },
                    featureSet: {
                        geometryType: geomType,
                        "features": [
                          {
                              "geometry": gra.geometry.toJson(),
                              "symbol": gra.symbol.toJson()
                          }
                        ]
                    }
                };
            } else {
                // We need a renderer to carry the label for the legend,
                // so we don't need the symbol in the "features" array.
                return {
                    layerDefinition: {
                        name: lyrName,
                        geometryType: geomType,
                        drawingInfo: {
                            renderer: new SimpleRenderer({
                                "label": lyrName,
                                "symbol": gra.symbol.toJson()
                            }).toJson()
                        }
                    },
                    featureSet: {
                        geometryType: geomType,
                        "features": [
                          {
                              "geometry": gra.geometry.toJson()
                          }
                        ]
                    }
                };
            }
        },

        mapExtentChanged: function (deltaPoint, newExtent, isLevelchange, lod) {
            // Just in case startup() gets called twice - BEGIN
            if (this.layoutInitialized) {
                return;
            }
            this.layoutInitialized = true;
            // Just in case startup() gets called twice - END
            this.lods = this._getLods();
            if (this.lods) {
                this.maxScale = this.lods[this.lods.length - 1].scale;
            }

            if (this.showLayout) {
                this.mapUnitsToMeters.x = this.mapUnitsToMeters.y = scaleUtils.getUnitValueForSR(this.map.spatialReference);
                if (!this.mapUnitsToMeters.x) {
                    // We cannot determine the map units, so don't show the layout.
                    this.showLayout = false;
                } else if (this.mapUnitsToMeters.x > 10000 || this.map.spatialReference.isWebMercator()) {
                    // If the spatial reference is geographic or Web Mercator, 
                    // call the geometry service to get the parameters to project the layout onto the map.  
                    // This is an approximation, but adequate for small geographic areas
                    // TODO: Check the map area to see if an approximation makes sense
                    var e = this.map.extent;  // TODO: change this to get the initial extent???
                    var lineN = new Polyline(this.map.spatialReference);
                    lineN.addPath([[e.xmin, e.ymax], [e.xmax, e.ymax]]);
                    var lineS = new Polyline(this.map.spatialReference);
                    lineS.addPath([[e.xmin, e.ymin], [e.xmax, e.ymin]]);
                    var lineE = new Polyline(this.map.spatialReference);
                    lineE.addPath([[e.xmax, e.ymax], [e.xmax, e.ymin]]);
                    var lineW = new Polyline(this.map.spatialReference);
                    lineW.addPath([[e.xmin, e.ymax], [e.xmin, e.ymin]]);
                    var eDims = { x: e.getWidth(), y: e.getHeight() };
                    var lp = new LengthsParameters();
                    lp.polylines = [lineN, lineS, lineE, lineW];
                    lp.lengthUnit = esri.tasks.GeometryService.UNIT_METER;
                    lp.geodesic = true;
                    esriConfig.defaults.geometryService.lengths(lp,
                      lang.hitch(this, function (result) {
                          if (result.lengths.length === 4) {
                              var southRatio = (result.lengths[0] / eDims.x);
                              var northRatio = (result.lengths[1] / eDims.x);
                              var westRatio = (result.lengths[2] / eDims.y);
                              var eastRatio = (result.lengths[3] / eDims.y);
                              // TODO: put in a check to fail if the ratios are too different?
                              this.mapUnitsToMeters.x *= (southRatio + northRatio) / 2;
                              this.mapUnitsToMeters.y *= (westRatio + eastRatio) / 2;
                          } else {
                              this.showLayout = false;
                              console.error("Get Map Units to Layout Units Conversion Factors");
                              console.error("Calculating conversion factors failed.  Print layouts will not be shown on the map.");
                          }
                      }),
                      lang.hitch(this, function () {
                         
                          this.showLayout = false;
                          console.error("Get Map Units to Layout Units Conversion Factors");
                          console.error("Calculating conversion factors failed.  Print layouts will not be shown on the map.");
                      })
                    );
                }
            }
            if (this.showLayout) {
                var currentWidget = this;
                // If we still want to show the layout, create a graphics layer for it.
                this.layoutLayer = new esri.layers.GraphicsLayer({ id: this.layoutLayerId, opacity: 1.0 });
                this.layoutLayer.spatialReference = this.map.spatialReference;
                this.map.addLayer(this.layoutLayer);
                this.layoutLayer._div && this.layoutLayer.enableMouseEvents();
                // Add the listener for the close graphic
                this.layoutLayer.on('click', lang.hitch(this, function (evt) {
                    if (evt.graphic.id === 'closeLayoutX' || evt.graphic.id === 'closeLayoutSq') {
                        // Stop event propagation so a popup isn't triggered.
                        evt.stopPropagation();
                        this._toggleShowLayout(false, true);
                    }
                }));
                this.toggleMapPanHandlers(true);
                if (this.reason === 'helpContent') {
                    // This widget was loaded just to populate the Help content, 
                    // so don't show the layout.
                    this._toggleShowLayout(false, false);
                }
            }
        },
        startup: function () {
            this.inherited(arguments);
        },
        show: function () {
            if (this.layoutLayer) {
                this.toggleLayoutLayer(true);
            }
        },
        hide: function () {
            this.isDocked = false;
            if (this.layoutLayer && !this.showLayoutDijit.get('value')) {
                this.toggleLayoutLayer(false);
            }
        },
        _resize: function (isDocked) {
            // isDocked is true if the widget is docked (fills the browser window).  This will always be true for devices with small screens (phones),
            // but may be true or false as the browser window size is changed on devices with larger screens.
            this.advancedSettingsDropDownDijit.closeDropDown();
            var dockStateChanged = isDocked !== this.isDocked;
            this.isDocked = isDocked;
            if (this.layoutLayer) {
                if (isDocked) {
                    // The widget is docked and has been resized by the browser window.
                    this.setScaleRanges();
                } else if (dockStateChanged && !isDocked) {
                    // The widget has been undocked.  Delete the scalebar ticks and labels so the scalebar can resize.
                    this.deleteTicksAndLabels();
                    // After a brief delay, add the ticks and labels.
                    setTimeout(this.setScaleRanges(), this.resizeDelay);
                } else {
                    // This ensures ticks and labels at startup (esp. on Chrome)
                    this.setScaleRanges();
                }
            }
        },
        toggleMapPanHandlers: function (turnOn) {
            if (this.layoutLayer && this.layoutLayer.visible && this.showLayoutDijit.get('value') && turnOn) {
                var _handler;
                this.mapSheetMoving = false;
                // Use pan events for adjusting the map relative to the layout on all devices.              
                _handler = this.map.on('pan-start', lang.hitch(this, function (evt) {
                    //'swipe-start'
                    // The 'screenPoint' property of the 'pan' event is not documented, but essential to the logic.
                    this.moveStartPt = this.map.toMap(evt.screenPoint);
                    if (typeof (this.mapAreaExtent) != "undefined") {
                        if (this.mapAreaExtent.contains(this.moveStartPt)) {
                            this.mapSheetMoving = true;
                            this.moveStartScreenPt = evt.screenPoint;
                        }
                    }
                }));
                this.dragSwipeHandlers.push(_handler);
                _handler = this.map.on('pan', lang.hitch(this, function (evt) {  //'swipe-move'
                    if (this.mapSheetMoving) {
                        this.moveEndScreenPt = this.moveStartScreenPt.offset(evt.delta.x, evt.delta.y);
                        moveEndPt = this.map.toMap(this.moveEndScreenPt);
                        var mOffset = { x: this.moveStartPt.x - moveEndPt.x, y: this.moveStartPt.y - moveEndPt.y };
                        this.moveMapSheet(mOffset);
                        this.moveStartPt = moveEndPt;
                        if (!this.map.extent.contains(this.mapAreaExtent)) {
                            this.adjustMapToLayout();
                        }

                    }
                }));
                this.dragSwipeHandlers.push(_handler);
                _handler = this.map.on('pan-end', lang.hitch(this, function () {  //'swipe-end'
                    if (this.mapSheetMoving) {
                        this.mapSheetMoving = false;
                        // To make sure the text is on top:
                        this.layoutLayer.clear();
                        this.drawMapSheet(this.mapAreaCenter);
                    }
                }));
                this.dragSwipeHandlers.push(_handler);
            } else {
                // Remove event handlers for panning and zooming when the layout is shown
                if (this.dragSwipeHandlers) {
                    array.forEach(this.dragSwipeHandlers, function (item) {
                        item.remove();
                        item = null;
                    });
                    this.dragSwipeHandlers = [];
                }
            }
        },
        togglePanZoomHandlers: function (turnOn) {
            if (turnOn && this.panZoomHandlers.length === 0 &&
                this.showLayoutDijit.get('value')) {
                // Add the event handlers for panning and zooming and resizing when the layout is shown.
                var _handler;
                _handler = this.map.on('zoom-end',
                    lang.hitch(this, function (evt) {
                        this.adjustLayoutToMap('zoom-end', evt.extent);
                    }));
                this.panZoomHandlers.push(_handler);
                _handler = this.map.on('pan-end',
                    lang.hitch(this, function (evt) {
                        this.adjustLayoutToMap('pan-end', evt.extent);
                    }));
                this.panZoomHandlers.push(_handler);
                _handler = this.map.on('resize', lang.hitch(this, function (evt) {
                    var resizeTimer;
                    var newExtent = evt.extent;
                    clearTimeout(resizeTimer);
                    // Set the delay to twice the delay used when the widget is docked or resized
                    resizeTimer = setTimeout(lang.hitch(this, function () {
                        this.map.resize();
                        this.map.reposition();
                        this.adjustLayoutToMap('resize', newExtent);
                    }), this.resizeDelay * 2);
                }));
                this.panZoomHandlers.push(_handler);
            } else if (!turnOn && this.panZoomHandlers.length > 0) {
                // Remove event handlers for panning and zooming and resizing when the layout is not shown.
                if (this.panZoomHandlers) {
                    array.forEach(this.panZoomHandlers, function (item) {
                        item.remove();
                        item = null;
                    });
                    this.panZoomHandlers = [];
                }
            }
        },
        _handleError: function (err) {
        
            console.log('print widget load error: ', err);
            new Message({
                message: err.message || err
            });
        },
        _handlePrintInfo: function (data) {
            var Layout_Template = array.filter(data.parameters, function (param) {
                return param.name === "Layout_Template";
            });
            if (Layout_Template.length === 0) {
               
                console.log("print service parameters name for templates must be \"Layout_Template\"");
                return;
            }
            var layoutParam;
            var layoutItems = array.map(Layout_Template[0].choiceList,
                lang.hitch(this, function (item) {
                    layoutParam = this.layoutParams[item];
                    return {
                        label: (layoutParam && layoutParam.alias ? layoutParam.alias : item).trim(),
                        noTb: "undefined" === typeof (item.noTb) ? true : item.noTb,
                        value: item.trim()
                    };
                }));
            // Filter out the No Title Block templates
            var index;
            var noTbLayouts = [];
            if (this.noTitleBlockPrefix) {
                layoutItems = array.filter(layoutItems, lang.hitch(this, function (item) {
                    index = item.value.indexOf(this.noTitleBlockPrefix);
                    if (index === 0) {
                        noTbLayouts.push(item.value.slice(this.noTitleBlockPrefix.length));
                        return false;
                    } else {
                        return true;
                    }
                }));
            }
            // Add a property to the layouts that have a corresponding "no title block" layout.
            if (noTbLayouts.length) {
                array.forEach(layoutItems, function (item) {
                    item.noTb = array.indexOf(noTbLayouts, item.value) !== -1;
                });
            }
            // Sort the layouts in the order they are listed in layoutParams (config.json).  If a layout is not included in layoutParams
            // (and has not been eliminated by the noTitleBlockPrefix filter above), put it at the end of the list.
            var keys = functional.keys(this.layoutParams);
            var bIndex;
            layoutItems.sort(function (a, b) {
                bIndex = array.indexOf(keys, b.value);
                return (bIndex !== -1) ? array.indexOf(keys, a.value) - bIndex : -1;
            });
            var defOption = document.createElement('option');
            defOption.value = ''; defOption.label = "";
            defOption.disabled = true;
            this.layoutDijit.appendChild(defOption);
            var dropdownnode = dojo.byId(this.layoutDijit);
            for (var i = 0; i < layoutItems.length; i++) {
                var opt = document.createElement("option");
                opt.value = layoutItems[i].value;
                opt.innerHTML = layoutItems[i].label;
                dropdownnode.appendChild(opt)
              //  dropdownnode.add(option);
            }
            //array.forEach(layoutItems, function (item) {
            //    var select = document.getElementById("layoutDijit");
            //    var opt = document.createElement("option");
            //    opt.value = item.value;
            //    opt.innerHTML = item.label;
            //    select.add(opt);
            //});
            this.mapSheetParams.layout = this.defaultLayout ?
                this.defaultLayout : Layout_Template[0].defaultValue;
            domAttr.set(this.layoutDijit, 'value', this.mapSheetParams.layout);
            this.onStateChange('LAYOUT', this.mapSheetParams.layout);
            var Format = array.filter(data.parameters, function (param) {
                return param.name === "Format";
            });
            if (0 === Format.length) {
              
                console.log("print service parameters name for format must be \"Format\"");
                return;
            }
            Format[0].choiceList.sort(function (a, b) {
                return (a > b) ? 1 : ((b > a) ? -1 : 0);
            });
           // Format[0].choiceList.splice(0, 1);
           // Format[0].choiceList.splice(6, 1);
           // Format[0].choiceList.splice(5, 1);

            //var formatItems = array.map(Format[0].choiceList, function (item) {
            //    var format = document.getElementById("formatDijit");
            //    var opt = document.createElement("option");
            //    opt.value = item;
            //    opt.innerHTML = item;

            //    format.add(opt);
            //});
            var format = dojo.byId(this.formatDijit)
            var formatItems = Format[0].choiceList;
            //var formatItems = array.map(Format[0].choiceList, function (item) {
            for (var i = 0; i < formatItems.length; i++) {
                var opt = document.createElement("option");
                opt.value = formatItems[i];
                opt.innerHTML = formatItems[i];
                format.appendChild(opt);

            }
      
             if (this.defaultFormat) {
                domAttr.set(this.formatDijit, 'value', this.defaultFormat);
            } else {
                domAttr.set(this.formatDijit, 'value', Format[0].defaultValue);
            }
        },
        print: function () {
            try {
                var currentWidget = this;
              
                if (dojo.byId(currentWidget.titleNode).value == "") {
                  
                    new Message({
                        titleLabel: "Print",
                        message: 'please enter title'
                    });

                    return;
                }
                if (dojo.byId(currentWidget.mapNumber).value == "") {
                   
                    new Message({
                        titleLabel: "Print",
                        message: 'please enter mapnumber'
                    });
                    return;
                }
                if (dojo.byId(currentWidget.layoutDijit).value == "") {
                   
                    new Message({
                        titleLabel: "Print",
                        message: 'please select Layout'
                    });
                    return;
                }



                var layoutFrame = this.layoutLayer.graphics.filter(function (item) {
                    return item.hasOwnProperty("frame");
                });
                if (1 === layoutFrame.length) {
                    layoutFrame = layoutFrame[0];
                    var geom = layoutFrame.geometry;
                    var geom = this.layoutLayer.graphics[0].geometry;
                    if (geom instanceof Polygon) {
                        var ring1 = geom.rings[0];
                        var minX = 9999999999.9999999, minY = 9999999999.9999999;
                        var maxX = -9999999999.9999999, maxY = -9999999999.9999999;
                        for (var i = 0; i < ring1.length; ++i) {
                            minX = Math.min(minX, ring1[i][0]);
                            minY = Math.min(minY, ring1[i][1]);

                            maxX = Math.max(maxX, ring1[i][0]);
                            maxY = Math.max(maxY, ring1[i][1]);
                        }
                        var poly = new Polygon(this.map.spatialReference);
                        var ringLayoutPerim = [[minX, minY],
                            [minX, maxY], [maxX, maxY],
                            [maxX, minY], [minX, minY]];
                        poly.addRing(lang.clone(ring1));
                        this.printExtents = poly.getExtent();
                    }
                }
                this.scaleToPrint = this.currentScale;
                this.preserve = this.preserveFormDijit.get('value');
                if (!this.layoutLayer) {
                    // If not showing the layout footprint, just call the original print function (renamed to submitPrintJob).
                    this.printExtents = this.map.extent;
                    this.submitPrintJob();
                } else if (this.mapSheetParams.layout === 'MAP_ONLY' && this.preserve.preserveScale === 'true') {
                    // For MAP_ONLY, just call the original print function (renamed to submitPrintJob).
                    this.printExtents = this.map.extent;
                    this.scaleToPrint = this.map.getScale();
                    this.submitPrintJob();
                    return;
                } else if (!this.printRequested) {
                    var printScale = this.mapSheetParams.layout === 'MAP_ONLY' ?
                        this.mapOnlyScale : this.scaleSliderDijit.get('value');
                    if (this.maxScale && printScale < this.maxScale) {
                        if (!confirm(this.nls.printScaleMessage)) {
                            return;
                        }
                    }
                    this.suspendExtentHandler = true;  //Suspend the Extent change handler
                    var def;
                    var oldLevel = null;
                    var oldCenter = null;
                    var oldExtent = null;
                    var oldLods = null;
                    if (this.lods) {
                        oldLevel = this.map.getLevel();
                        oldCenter = this.map.extent.getCenter();
                        printScaleLevel = this._getLevel(this.lods, printScale);
                        // Set one LOD for the printing scale and zoom to it.
                        if (printScaleLevel) {
                            def = this.map.centerAt(this.printExtents);
                        } else {
                            oldLods = this.lods;
                            var resolution = printScale / (oldLods[0].scale / oldLods[0].resolution);
                            var printLod = [{ 'level': 0, 'resolution': resolution, 'scale': printScale }];
                            this._setLods(printLod);
                            this.scaleToPrint = printScale;
                            def = this.map.setExtent(this.printExtents, true);
                        }
                    } else {
                        // Zoom to the print scale
                        oldExtent = this.map.extent;
                        this.scaleToPrint = printScale;
                        def = this.map.centerAt(this.printExtents);
                    }
                    this.updateStartListener = on.once(this.map, 'update-start',
                        lang.hitch(this, function () {
                            this.mapUpdating = true;
                        }));
                    this.updateEndListener = on.once(this.map, 'update-end',
                        lang.hitch(this, 'printAndRestoreSettings', oldLevel, oldCenter, oldExtent, oldLods));

                    def.then(lang.hitch(this, function () {
                        if (!this.mapUpdating) {
                            this.scaleToPrint = this.map.getScale();
                            // The zoom did not cause the map to update, so remove those listeners and print.
                            this.updateStartListener.remove();
                            this.updateStartListener = null;
                            this.updateEndListener.remove();
                            this.updateEndListener = null;
                            this.printAndRestoreSettings(oldLevel, oldCenter, oldExtent, oldLods);
                        }
                    }));
                }
            }
            catch (e) {
              
            }
        },

        printAndRestoreSettings: function (oldLevel, oldCenter, oldExtent, oldLods) {
            this.mapUpdating = false;
            this.submitPrintJob();

            var def;
            if (oldCenter && oldLevel) {
                if (oldLods) {
                    // Restore the LODs if they were changed.
                    this._setLods(oldLods);
                }
                def = this.map.centerAndZoom(oldCenter, oldLevel);
            } else if (oldExtent) {
                def = this.map.setExtent(oldExtent);
            }
            if (def != undefined) {
                // Restore the map extent and the graphics layer opacity.
                def.then(lang.hitch(this, function () {
                    this.suspendExtentHandler = false;
                }));
            }
     
        },

        _setLods: function (lods) {
            lang.setObject('__tileInfo.lods', lods, this.map);
            lang.setObject('_params.lods', lods, this.map);
            lang.setObject('_params.tileInfo.lods', lods, this.map);
            if (this.mapLods) {
                lang.setObject('_mapParams.lods', lods, this.map);
            }
        },

        _getLods: function () {
            var lods = lang.getObject('_params.tileInfo.lods', false, this.map);
            return lods && lods.length ? lods : null;
        },

     

        _getLevel: function (lods, scale) {
            var level;
            array.some(lods, function (lod) {
                if (lod.scale === scale) {
                    level = lod.level;
                    return true;
                }
            });
            return level;
        },

        submitPrintJob: function () {

            var currentWidget = this;
            var mapnumber = dojo.byId('mapNumber').value;
           
            if (this.printSettingsFormDijit.isValid()) {
                this.layoutLayer && this.layoutLayer.hide();
                var form = this.printSettingsFormDijit.get('value');
                lang.mixin(form, this.layoutMetadataDijit.get('value'));
                form.format = domAttr.get(this.formatDijit, "value");
                form.layout = domAttr.get(this.layoutDijit, "value");

                form.title = dojo.byId(currentWidget.titleNode).value;         
                if (form.layout !== 'MAP_ONLY') {
                    // Set this here so it doesn't change the user's settings for MAP_ONLY
                    this.preserve.preserveScale = 'false';
                }
                lang.mixin(form, this.preserve);
                this.layoutForm = this.layoutFormDijit.get('value');
                var mapQualityForm = this.mapQualityFormDijit.get('value');
                var mapOnlyForm = this.mapOnlyFormDijit.get('value');
                var dpiConversion = mapOnlyForm.printUnits === Units.INCHES ? 1 : 0.3937;
                mapOnlyForm.dpi = domAttr.get(this.dpiQualityDijit, 'value');
               
                if (mapOnlyForm.dpi > 100 && form.format == 'PDF') {
                    mapOnlyForm.width = 60.83;
                    mapOnlyForm.height = 32.91;
                }
                mapOnlyForm.width = mapOnlyForm.width * dpi * dpiConversion;
                mapOnlyForm.height = mapOnlyForm.height * dpi * dpiConversion;
                mapQualityForm.dpi = domAttr.get(this.dpiQualityDijit, 'value');
               
                lang.mixin(mapOnlyForm, mapQualityForm);
                this.noTitleBlockPrefix = '';
                var template = new PrintTemplate();
                template.format = form.format;
                template.layout = form.layout === 'MAP_ONLY' || this.titleBlock ? form.layout : this.noTitleBlockPrefix + form.layout;
                template.label = form.title;
                template.exportOptions = mapOnlyForm;
                template.layoutOptions = {
                    authorText: form.author,
                    copyrightText: form.copyright,
                    legendLayers: (this.layoutForm.legend.length > 0 && this.layoutForm.legend[0]) ? null : [],
                    titleText: form.title,
                    scalebarUnit: "Feet",
                    customTextElements: [
                        { "user": "Demo" },
                        { "maptype": currentWidget.maptype },
                        { "mapnumber": mapnumber }
                    ]
                };
                if (this.titleBlock == false) {
                    template.layoutOptions = {
                        authorText: form.author,
                        copyrightText: form.copyright,
                        legendLayers: (this.layoutForm.legend.length > 0 && this.layoutForm.legend[0]) ? null : [],
                        titleText: "",
                        scalebarUnit: "Feet",
                        customTextElements: [
                            { "user": currentWidget.userName },
                            { "maptype": currentWidget.maptype },
                            { "mapnumber": mapnumber }
                        ]
                    };
                }
                this.printparams.template = template;
                this.printparams.extraParameters = { // come from source code of jsapi
                    printFlag: true
                };
                var fileHandel = this.exportWebMap(this.printTask, template.format, template.layout);
                var result = new PrintResultDijit({
                    count: this.count.toString(),
                    icon: (form.format === "PDF") ? this.pdfIcon : this.imageIcon,
                    docName: form.title || (form.layout === 'MAP_ONLY' ? 'Just the map' : 'No Titleblock'),  //lcs - docName is not used
                    title: form.title || (form.format + ', ' + form.layout),  //lcs - disabled form items are ignored
                    fileHandle: fileHandel,
                    nls: this.nls
                }).placeAt(this.printResultsNode, 'last');
                result.startup();
                this.layoutLayer && this.layoutLayer.show();
                domStyle.set(this.clearActionBarNode, 'display', 'block');
                this.count++;
            } else {
                this.printSettingsFormDijit.validate();
            }
        },
        exportWebMap: function (printTask, format, layout) {
            var currentWidget = this;
            var template = currentWidget.printparams.template
            var layoutOptions = currentWidget.getLayoutOptions(printTask, template);
            var exportOptions = currentWidget.getExportOptions(template);
            var printDef = printTask._getPrintDefinition(currentWidget.map,
                                    currentWidget.printparams);

            if ("undefined" !== typeof (currentWidget.printparams.outSpatialReference) &&
               null !== currentWidget.printparams.outSpatialReference)
                printDef.mapOptions.spatialReference = currentWidget.printparams.outSpatialReference.toJson();
            if ("undefined" !== typeof (template.showAttribution) &&
                null !== template.showAttribution)
                printDef.mapOptions.showAttribution = template.showAttribution;
            if ("undefined" !== typeof (this.printExtents) && null !== this.printExtents)
                printDef.mapOptions.extent = this.printExtents.toJson();
            var webMap = JSON.parse(dojoJSON.toJson(currentWidget.normalizeJson(printDef)));
            var operationalLayers = webMap["operationalLayers"];
            webMap["operationalLayers"] = currentWidget.getOperationLayersFixed(operationalLayers);
            lang.mixin(webMap, {
                exportOptions: exportOptions,
                layoutOptions: layoutOptions
            });
            var webMapJson = JSON.stringify(webMap);
            var tweakedPrintOptions = {
                Web_Map_as_JSON: webMapJson,
                Format: format,
                Layout_Template: layout
            };
            if (currentWidget.printparams.extraParameters)
                tweakedPrintOptions = lang.mixin(tweakedPrintOptions,
                        currentWidget.printparams.extraParameters);
            var payLoad = lang.mixin(tweakedPrintOptions, { f: "json" });
            var url = this.serviceURL.replace(/^http:\/\//i, 'https://') + "/execute"
            var dfd = esriRequest({
                url: url,
                content: payLoad,
                handleAs: "json",
                callbackParamName: "callback",
                timeout: 360000
            }, {
                "usePost": true
            });
            return dfd;
        },
        getLayoutOptions: function (printTask, template) {
            var currentWidget = this;
            printTask["legendAll"] = false;
            template.hasOwnProperty("showLabels") || (template.showLabels = true);
            var layoutOptions = template.layoutOptions;
            var layerConfigs = new Array();
            if (layoutOptions.legendLayers) {
                array.forEach(layoutOptions.legendLayers, function (el) {
                    var layerConfigObj = {};
                    layerConfigObj.id = el.layerId;
                    if (el.subLayerIds)
                        layerConfigObj.subLayerIds = el.subLayerIds;
                    layerConfigs.push(layerConfigObj);
                });
            }
            else {
                printTask["legendAll"] = true;
            }
            var metricUnit, nonMetricUnit;
            var metricLabel, nonMetricLabel;
            if ("Miles" === layoutOptions.scalebarUnit ||
                "Kilometers" === layoutOptions.scalebarUnit) {
                metricUnit = "esriKilometers"; metricLabel = "km";
                nonMetricUnit = "esriMiles"; nonMetricLabel = "mi";
            }
            else if ("Meters" === layoutOptions.scalebarUnit ||
                "Feet" === layoutOptions.scalebarUnit) {
                metricUnit = "esriMeters"; metricLabel = "m";
                nonMetricUnit = "esriFeet"; nonMetricLabel = "ft";
            }
            return {
                titleText: layoutOptions.titleText,
                authorText: layoutOptions.authorText,
                copyrightText: layoutOptions.copyrightText,
                customTextElements: layoutOptions.customTextElements,
                scaleBarOptions: {
                    metricUnit: metricUnit,
                    metricLabel: metricLabel,
                    nonMetricUnit: nonMetricUnit,
                    nonMetricLabel: nonMetricLabel
                },
                legendOptions: {
                    operationalLayers: layerConfigs
                }
            };
        },
        getExportOptions: function (template) {
            var currentWidget = this;
            var opts = template.exportOptions;
            var exportOptions;
            if (opts) {
                exportOptions = {
                    outputSize: [opts.width, opts.height],
                    dpi: opts.dpi
                }
            }
            return exportOptions;
        },
        getOperationLayersFixed: function (operationalLayers) {
            var currentWidget = this;
            var operationalLayersDraw = null;
            var operationalLayersDraw = [];
            for (var i = 0; i < operationalLayers.length; ++i) {
                if (operationalLayers[i].id === this.layoutLayerId)
                    continue;
                var testValue = null;
                var testUrl = "";
                testValue = lang.clone(operationalLayers[i]);
                testURL = operationalLayers[i]["url"];
                if (testURL !== null && testURL !== undefined) {
                    if (testURL.startsWith("//"))
                        testValue["url"] = "https:" + testValue["url"];
                    testValue["url"] = testValue["url"].replace(/^http:\/\//i, 'https://');
                    operationalLayersDraw.push(testValue);
                }
                else {
                    operationalLayersDraw.push(testValue);
                }
            }
            return operationalLayersDraw;
        },
        normalizeJson: function (jsonObj, c) {
            var currentWidget = this
            var prop;
            if (c) {
                for (prop in jsObj) {
                    if (jsonObj.hasOwnProperty(prop)) {
                        if (void 0 === jsonObj[prop])
                            delete jsonObj[prop];
                        else {
                            // call recursively till all the nested properties are normalized
                            if (jsonObj[prop] instanceof Object)
                                currentWidget.normalizeJson(jsonObj[prop], true);
                        }
                    }
                }
            }
            else {
                for (prop in jsonObj) {
                    if (jsonObj.hasOwnProperty(prop))
                        if (void 0 === jsonObj[prop])
                            delete jsonObj[prop];
                }
            }
            return jsonObj;
        },
        clearResults: function () {
            var currentWidget = this;
            domConstruct.empty(this.printResultsNode);
            domStyle.set(this.clearActionBarNode, 'display', 'none');
            currentWidget.count = 1;
        },
        updateAuthor: function (user) {
            user = user || '';
            if (user) {
                this.authorTB.set('value', user);
            }
        },
        getCurrentMapScale: function () {
            this.forceScaleNTB.set('value', this.map.getScale());
        },

        _onTitleBlockChange: function (value) {
            // Set the visibilities of the print options
            this.titleBlock = value;
            this.onStateChange('TITLE_BLOCK', value);
            // Don't draw a layout if there is no graphics layer
            if (this.layoutLayer) {
                this.layoutLayer.clear();
                this.setScaleRanges();
                if (this.showLayoutDijit.get('value')) {
                    this.drawMapSheet(this.mapAreaCenter);
                }
            }
        },
        _onLayoutChange: function (evt) {
            var currentWidget = this;
           
            domStyle.set(dom.byId(currentWidget.scaleSliderDiv), "display", "block");


            dojo.removeClass("plaecHldr", "textPlaceholder")

            var selectItem = evt.target;
            var layout = selectItem.value;
            if (layout != null) {
                this.isLayout = true;
            }
            if (layout.indexOf('SDE') > -1)
                currentWidget.maptype = "Electric Asset Map";
            else
                currentWidget.maptype = "Gas Asset Map";
            // If changing from or to 'MAP_ONLY', this is a state change
            if (this.mapSheetParams.layout === 'MAP_ONLY' || layout === 'MAP_ONLY') {
                this.onStateChange('LAYOUT', layout);
            }
            this.mapSheetParams.layout = layout;
            // Hide the title block checkbox is there is no companion layout with no title block.
            var noTb = false;
            array.some(this.layoutDijit.options, function (option) {
                if (option.value === layout) {
                    noTb = option.noTb;
                    return true;
                }
            });
            query('#titleBlock', this.domNode).style('visibility', noTb ? '' : 'visible');
            // Draw the map sheet
            if (this.cleargraphics) {
                this.layoutLayer.remove(this.cleargraphics);
               // this.layoutLayer.graphics.clear();
            }
           
            if (this.layoutLayer)
                this.layoutLayer.clear();
            if (dojo.byId(this.showLayoutDijit).checked != true) {
                dojo.byId(this.showLayoutDijit).checked = true;
            }
            if (layout === 'MAP_ONLY') {
                // Remove the graphic layer pan and zoom handlers
                this.togglePanZoomHandlers(false);
                // Set the map sketch to reflect the settings
                this._adjustMapSketch();
            } else {
                // Add the graphic layer pan and zoom handlers
                this.togglePanZoomHandlers(true);
                if (this.layoutParams && this.layoutParams[layout]) {
                    var layoutUnitsToMeters = this.getUnitToMetersFactor(this.layoutParams[layout].units);
                    this.mapSheetParams = {
                        layout: layout,
                        pageSize: this.layoutParams[layout].pageSize,
                        mapSize: this.layoutParams[layout].mapFrame,
                        unitRatio: { x: layoutUnitsToMeters.x / this.mapUnitsToMeters.x, y: layoutUnitsToMeters.y / this.mapUnitsToMeters.y },
                        items: this.layoutParams[layout].items
                    };
                    var centerPt = this.map.extent.getCenter();
                    this.setScaleRanges();
                    if (this.showLayoutDijit.get('value')) {
                        this.drawMapSheet(centerPt);
                    }
                }
            }

        },
        _onScaleBoxChange: function (value) {
            if (this.isSliderChange == true) {
                if (value < this.scaleSliderDijit.minimum) {
                    value = this.scaleSliderDijit.minimum;
                } else if (value > this.scaleSliderDijit.maximum) {
                    value = this.scaleSliderDijit.maximum;
                }
            }
            else if (this.isSliderChange == false) {
                value = this.scaleSliderDijit.maximum;
            }
            this.scaleBoxDijit.set('value', value);
            this.scaleSliderDijit.set('value', value);
        },
        _onScaleSliderChange: function (value) {
            var currentWidget = this;
            currentWidget.isSliderChange = true;
            // Don't draw a layout if there is no graphics layer
            if (this.layoutLayer) {
                this.scaleBoxDijit.set('value', value);
                var domRelativeScale = dom.byId('relativeScale');
                if (domRelativeScale) {
                    domRelativeScale.innerHTML = this.relativeScale.replace('[value]',
                        number.format(value * this.relativeScaleFactor, { places: this.scalePrecision }));
                    currentWidget.scaleUnitValue = number.format(value * this.relativeScaleFactor, { places: this.scalePrecision });
                }
                this.layoutLayer.clear();
                if (!this.mapAreaCenter) {
                    this.mapAreaCenter = this.map.extent.getCenter();
                }
                this.drawMapSheet(this.mapAreaCenter);
                this.adjustLayoutToMap('printScaleChange', this.map.extent);
            }
        },
        drawMapSheet: function (centerPt) {
            this.layoutLayer.enableMouseEvents();
            this.layoutLayer.clear();
            var pageSize = this.mapSheetParams.pageSize;
            var unitRatio = this.mapSheetParams.unitRatio;
            var layoutItems = this.mapSheetParams.items;
            var mapOffsets;
            var mapDims = this.mapSheetParams.mapSize;
            this.currentPageSize = pageSize;
            this.currentUnitRatio = unitRatio;
            var mapExtent = this.map.extent;
            var scale = this.scaleSliderDijit.get('value');
            this.currentScale = scale;

            var layoutMinX = centerPt.x - pageSize.width / 2 * scale * unitRatio.x;
            var layoutMinY = centerPt.y - pageSize.height / 2 * scale * unitRatio.y;
            var layoutMaxX = centerPt.x + pageSize.width / 2 * scale * unitRatio.x;
            var layoutMaxY = centerPt.y + pageSize.height / 2 * scale * unitRatio.y;

            //// Calculate the boundaries for the print area 
            var minX = layoutMinX + mapDims.x * scale * unitRatio.x;
            var minY = layoutMinY + mapDims.y * scale * unitRatio.y;
            var maxX = minX + mapDims.width * scale * unitRatio.x;
            var maxY = minY + mapDims.height * scale * unitRatio.y;

            var pageDims = {
                xMin: minX, yMin: minY,
                xMax: maxX, yMax: maxY,
            }

            // List the points in counter-clockwise order (this is the hole for the map)
            var ringMapArea = [[minX, minY], [maxX, minY],
                        [maxX, maxY], [minX, maxY], [minX, minY]];

            this.layoutMapArea = ringMapArea;

            // Update the map area center and extent so other functions can use them
            this.mapAreaCenter = centerPt;
            this.mapAreaExtent = new Extent(minX, minY, maxX, maxY, this.map.spatialReference);

            // Capture the upper right corner of the map area
            var insideX = maxX;
            var insideY = maxY;

            // Get the ratio of map units to pixels
            var mapUnitsToPixels = this.map.extent.getWidth() / this.map.width;
            // Calculate the margin width for the close symbol in map units
            var layoutMargin = Math.min(layoutMaxX - insideX, layoutMaxY - insideY);
            // Calculate the size of the close symbol in pixels
            var closeBtnSize = Math.min(30, Math.round(layoutMargin / mapUnitsToPixels) - 2);
            // Set the line widths of the layout and close symbols
            var layoutLineWidth = Math.max(Math.round(closeBtnSize / 3), 1);
            var closeBtnLineWidth = Math.max(Math.round(closeBtnSize / 6), 1);
            // Calculate the offset for the close symbol in map units
            var closeBtnOffset = (closeBtnSize + 4) * mapUnitsToPixels / 2;
            // Establish the point for the close symbol
            var ptCloseBtn = new Point(layoutMaxX - closeBtnOffset,
                layoutMaxY - closeBtnOffset, this.map.spatialReference);

            // list the points in clockwise order (this is the paper)
            var ringLayoutPerim = [[layoutMinX, layoutMinY],
                [layoutMinX, layoutMaxY], [layoutMaxX, layoutMaxY],
                [layoutMaxX, layoutMinY], [layoutMinX, layoutMinY]];

            var geomLayout = new Polygon(this.map.spatialReference);
            geomLayout.addRing(ringMapArea);
            geomLayout.addRing(ringLayoutPerim);

            var symLayout = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                new CartographicLineSymbol(
                                  CartographicLineSymbol.STYLE_SOLID,
                                  new Color([0, 0, 0]), 2,
                                  CartographicLineSymbol.CAP_ROUND,
                                  CartographicLineSymbol.JOIN_ROUND),
                                new Color([255, 255, 255]));

            var graLayout = new Graphic(geomLayout, symLayout);
            graLayout["frame"] = true;

            this.cleargraphics = graLayout;

            this.layoutLayer.add(graLayout);

            // Create the close symbols
            var symCloseBtnX = new SimpleMarkerSymbol({
                "color": [0, 0, 0, 255],
                "size": 10,
                "angle": 0,
                "xoffset": 0,
                "yoffset": 0,
                "type": "esriSMS",
                "style": "esriSMSX",
                "outline": {
                    "color": [0, 0, 0, 255],
                    "width": 2,
                    "type": "esriSLS",
                    "style": "esriSLSSolid"
                }
            });
            symCloseBtnX.setSize(closeBtnSize - closeBtnLineWidth);
            symCloseBtnX.outline.width = closeBtnLineWidth;

            var symCloseBtnOutline = new SimpleMarkerSymbol({
                "color": [0, 0, 0, 0],
                "size": 12,
                "angle": 0,
                "xoffset": 0,
                "yoffset": 0,
                "type": "esriSMS",
                "style": "esriSMSSquare",
                "outline": {
                    "color": [0, 0, 0, 255],
                    "width": 1,
                    "type": "esriSLS",
                    "style": "esriSLSSolid"
                }
            });
            symCloseBtnOutline.setSize(closeBtnSize);
            symCloseBtnOutline.outline.width = closeBtnLineWidth;

            // Add the close graphics
            var graCloseBtnOutline = new Graphic(ptCloseBtn, symCloseBtnOutline);
            graCloseBtnOutline.id = 'closeLayoutSq';
            this.layoutLayer.add(graCloseBtnOutline);
            var graCloseBtnX = new Graphic(ptCloseBtn, symCloseBtnX);
            graCloseBtnX.id = 'closeLayoutX';
            this.layoutLayer.add(graCloseBtnX);

            var layoutDims = {
                xMin: layoutMinX, yMin: layoutMinY,
                xMax: layoutMaxX, yMax: layoutMaxY,
            }

            for (var i = 0; i < layoutItems.length; ++i) {
                var layoutItem = layoutItems[i];
                switch (layoutItem.type) {
                    case "image":

                        var pictureGrfx = this.createImageElement(layoutDims, pageDims, scale,
                                                    unitRatio, layoutItem);
                        null !== pictureGrfx && this.layoutLayer.add(pictureGrfx);

                        break;

                    case "box":
                        var boxGrfx = this.createBoxElement(layoutDims, pageDims, scale,
                                                    unitRatio, layoutItem);
                        null !== boxGrfx && this.layoutLayer.add(boxGrfx);

                        break;

                    case "text":
                        var textGrfx = this.createTextElement(layoutDims, pageDims, scale,
                                                   unitRatio, layoutItem);
                        null !== textGrfx && this.layoutLayer.add(textGrfx);

                        break;
                }


            }
        },
        createImageElement: function (layoutDims, pageDims, scale, unitRatio, layoutItem) {
            var pictureGrfx = null;
            try {
                var pageLeftMargin = pageDims.xMin - layoutDims.xMin;
                var availableWidth = (layoutDims.xMax - layoutDims.xMin) -
                    (pageDims.xMax - pageDims.xMin) - pageLeftMargin;


                var minX = layoutDims.xMin + layoutItem.position.x * scale * unitRatio.x;
                var minY = layoutDims.yMin + layoutItem.position.y * scale * unitRatio.y;
                var maxX = minX + layoutItem.size.width * scale * unitRatio.x;
                var maxY = minY + layoutItem.size.height * scale * unitRatio.y;

                var width = maxX - minX; // this is in map units
                var height = maxY - minY; // this is in map units   

                if (width > availableWidth)
                    width = availableWidth;
                var widthPx = width / (this.map.extent.getWidth() / this.map.width);
                var heightPx = height / (this.map.extent.getHeight() / this.map.height);

                var imgUrl = require.toUrl(layoutItem.itemInfo.url);
                var offsetX = offsetY = 0;

                var pictPolygon = new Polygon(this.map.spatialReference);
                var picturePerim = [[minX, minY],
                    [minX, maxY], [maxX, maxY],
                    [maxX, minY], [minX, minY]];
                pictPolygon.addRing(picturePerim);
                var pictMarkerSymbol = this.createSymbolFromJSON(lang.mixin(layoutItem.symbol,
                    { "width": widthPx * 0.9, height: heightPx }));
                pictMarkerSymbol.setWidth(widthPx);
                pictMarkerSymbol.setHeight(heightPx);
                var pictMarkerGeom = pictPolygon.getCentroid();

                var pictureGrfx = new Graphic(pictMarkerGeom, pictMarkerSymbol);
            }
            catch (ex) {
                console.log("Exception while creating picture element : " + ex.message);
            }
            return pictureGrfx;
        },
        createTextElement: function (layoutDims, pageSize, scale, unitRatio, layoutItem) {
            var grfx = null;
            try {
                var minX = layoutDims.xMin + layoutItem.position.x * scale * unitRatio.x;
                var minY = layoutDims.yMin + layoutItem.position.y * scale * unitRatio.y;
                var maxX = minX + layoutItem.size.width * scale * unitRatio.x;
                var maxY = minY + layoutItem.size.height * scale * unitRatio.y;

                var width = maxX - minX; // this is in map units
                var height = maxY - minY; // this is in map units   

                var widthPx = width / (this.map.extent.getWidth() / this.map.width);
                var heightPx = height / (this.map.extent.getHeight() / this.map.height);

                var offsetX = "undefined" !== typeof (layoutItem.position.offsetX) ?
                     layoutItem.position.offsetX / (this.map.extent.getWidth() / this.map.width) : 0;

                var offsetY = "undefined" !== typeof (layoutItem.position.offsetY) ?
                   layoutItem.position.offsetY(this.map.extent.getHeight() / this.map.height) : 0;

                var boxGeom = new Polygon(this.map.spatialReference);
                var boxPerimeter = [[minX, minY],
                    [minX, maxY], [maxX, maxY],
                    [maxX, minY], [minX, minY]];
                boxGeom.addRing(boxPerimeter);
                var textInsGeom = boxGeom.getCentroid();

                var symbol = this.createSymbolFromJSON(layoutItem.symbol);
                grfx = new Graphic(textInsGeom, symbol);
            }
            catch (ex) {
               
                console.log("Exception while creating text element : " + ex.message);
            }
            return grfx;
        },

        createBoxElement: function (layoutDims, pageSize, scale, unitRatio, layoutItem) {
            var grfx = null;
            try {
                var minX = layoutDims.xMin + layoutItem.position.x * scale * unitRatio.x;
                var minY = layoutDims.yMin + layoutItem.position.y * scale * unitRatio.y;
                var maxX = minX + layoutItem.size.width * scale * unitRatio.x;
                var maxY = minY + layoutItem.size.height * scale * unitRatio.y;

                var boxGeom = new Polygon(this.map.spatialReference);
                var boxPerimeter = [[minX, minY],
                    [minX, maxY], [maxX, maxY],
                    [maxX, minY], [minX, minY]];
                boxGeom.addRing(boxPerimeter);

                var symbol = this.createSymbolFromJSON(layoutItem.symbol);
                grfx = new Graphic(boxGeom, symbol);
            }
            catch (ex) {
               
                console.log("Exception while creating box element : " + ex.message);
            }

            return grfx;
        },
        createSymbolFromJSON: function (symbolJSON) {
            var symbol = null;
            if ("undefined" === typeof (symbolJSON) ||
                "undefined" === typeof (symbolJSON.type))
                return symbol;

            switch (symbolJSON.type) {
                case "esriSFS":
                    symbol = new SimpleFillSymbol(symbolJSON);
                    break;
                case "esriTS":
                    symbol = new TextSymbol(symbolJSON);
                    break;
                case "esriPMS":
                    symbol = new PictureMarkerSymbol(symbolJSON);
                    break;
            }
            return symbol
        },
        moveMapSheet: function (mOffset) {
            var i, j, pt;
            this.mapAreaCenter = this.mapAreaCenter.offset(mOffset.x, mOffset.y);
            this.mapAreaExtent = this.mapAreaExtent.centerAt(this.mapAreaCenter);

            array.forEach(this.layoutLayer.graphics, lang.hitch(this, function (gra) {
                switch (gra.geometry.type) {
                    case "point":
                        pt = gra.geometry.offset(mOffset.x, mOffset.y);
                        gra.setGeometry(pt);
                        break;
                    case "polyline":
                        // This case has not been tested!
                        var polyline = new Polyline(gra.geometry);
                        for (i = 0; i < polyline.paths.length; i++) {
                            for (j = 0; j < polyline.paths[i].length; j++) {
                                pt = polyline.getPoint(i, j).offset(mOffset.x, mOffset.y);
                                polyline.setPoint(i, j, pt);
                            }
                        }
                        gra.setGeometry(polyline);
                        break;
                    case "polygon":
                        var polygon = new Polygon(gra.geometry);
                        for (i = 0; i < polygon.rings.length; i++) {
                            for (j = 0; j < polygon.rings[i].length; j++) {
                                pt = polygon.getPoint(i, j).offset(mOffset.x, mOffset.y);
                                polygon.setPoint(i, j, pt);
                            }
                        }
                        gra.setGeometry(polygon);
                        break;
                    case "extent":
                        var extent = gra.geometry.offset(mOffset.x, mOffset.y);
                        gra.setGeometry(extent);
                        break;
                }
            }));

            this.layoutLayer.redraw();
        },

        _adjustMapSketch: function () {
            // Get the preserve scale, width, and height settings and draw the map sketch if there is enough data
            var preserveScale = this.preserveFormDijit.get('value').preserveScale === 'true';
            var mapOnlyForm = this.mapOnlyFormDijit.get('value');
            var printUnits = mapOnlyForm.printUnits;
            var printWidth = mapOnlyForm.width;
            var printHeight = mapOnlyForm.height;
            var extentWidth = this.map.extent.getWidth();
            var extentHeight = this.map.extent.getHeight();
            var paperMapDims = new Dims(printWidth, printHeight);
            var layoutUnitsToMeters = this.getUnitToMetersFactor(printUnits);
            var unitRatio = { x: layoutUnitsToMeters.x / this.mapUnitsToMeters.x, y: layoutUnitsToMeters.y / this.mapUnitsToMeters.y };
            var paperAspectRatio, browserAspectRatio;
            var browserMapDims;
            var scale;
            if (preserveScale) {
                // Calculate the extent to be printed
                scale = this.map.getScale();
                browserMapDims = new Dims(extentWidth / scale / unitRatio.x, extentHeight / scale / unitRatio.y);
            } else {
                // Calculate the scale
                paperAspectRatio = printWidth / printHeight;
                browserAspectRatio = extentWidth / extentHeight;
                if (paperAspectRatio > browserAspectRatio) {
                    scale = (extentHeight / printHeight) / unitRatio.y;
                    browserMapDims = new Dims(paperMapDims.x * browserAspectRatio / paperAspectRatio, paperMapDims.y);
                } else {
                    scale = (extentWidth / printWidth) / unitRatio.x;
                    browserMapDims = new Dims(paperMapDims.x, paperMapDims.y * paperAspectRatio / browserAspectRatio);
                }
                this.mapOnlyScale = scale;
            }
            if (!printWidth || !printHeight || printWidth <= 0 || printHeight <= 0) {
                // Can't draw the sketch
            }

            var max = 200;  // This should be coordinated with the width of the Advanced dropdown
            var offset = 47;  // This should be coordinated with the width of the Advanced dropdown

            // Normalize the map sizes to the space available
            var normalize = Math.max(paperMapDims.x, paperMapDims.y, browserMapDims.x, browserMapDims.y) / max;
            paperMapDims = new Dims(paperMapDims.x / normalize, paperMapDims.y / normalize);
            browserMapDims = new Dims(browserMapDims.x / normalize, browserMapDims.y / normalize);

            // Calculate the offsets required to center both rectangles
            var paperMapOffset = new Dims((offset + max - paperMapDims.x) / 2, Math.max(0, (browserMapDims.y - paperMapDims.y) / 2));
            var browserMapOffset = new Dims((offset + max - browserMapDims.x) / 2, Math.max(0, (paperMapDims.y - browserMapDims.y) / 2));

            // Draw the paper map extent
            var paperMap = dom.byId('paperMap');
            paperMap.style.position = (paperMapDims.y <= browserMapDims.y) ? 'absolute' : 'relative';
            paperMap.style.width = paperMapDims.x.toFixed(0) + 'px';
            paperMap.style.height = paperMapDims.y.toFixed(0) + 'px';
            paperMap.style.left = paperMapOffset.x.toFixed(0) + 'px';
            paperMap.style.top = paperMapOffset.y.toFixed(0) + 'px';

            // Draw the extent of the map in the  browser window
            var browserMap = dom.byId('browserMap');
            browserMap.style.position = (browserMapDims.y < paperMapDims.y) ? 'absolute' : 'relative';
            browserMap.style.width = browserMapDims.x.toFixed(0) + 'px';
            browserMap.style.height = browserMapDims.y.toFixed(0) + 'px';
            browserMap.style.left = browserMapOffset.x.toFixed(0) + 'px';
            browserMap.style.top = browserMapOffset.y.toFixed(0) + 'px';

            // The Dims object is like a Point, only much leaner
            function Dims(x, y) {
                this.x = x;
                this.y = y;
            }
        },

        adjustLayoutToMap: function (evtType, mapExtent) {
            if (!this.suspendExtentHandler) {
                var centerPt;
                if (!evtType || evtType === 'zoom-end') {
                    // This was a zoom, so reset the scales and redraw the layout
                    this.setScaleRanges(mapExtent);
                    centerPt = mapExtent.getCenter();
                    this.layoutLayer.clear();
                    this.drawMapSheet(centerPt);
                } else if (this.mapAreaExtent && !mapExtent.contains(this.mapAreaExtent)) {
                    // Map extent does not contain the layout's map area.
                    if (evtType === 'printScaleChange') {
                        // Redraw the layout so it is within the map extents if the print scale has been changed.
                        var correction = this.getCorrection(mapExtent);
                        centerPt = this.mapAreaCenter.offset(correction.x, correction.y);
                    } else {
                        // Redraw the layout in the center of the map extent if there was a different cause
                        centerPt = mapExtent.getCenter();
                        this.setScaleRanges(mapExtent);
                    }
                    this.layoutLayer.clear();
                    this.drawMapSheet(centerPt);
                } else if (evtType === 'resize') {
                    this.setScaleRanges(mapExtent);
                }
            }
        },

        adjustMapToLayout: function () {
            var correction = this.getCorrection();
            this.suspendExtentHandler = true;
            this.map.setExtent(this.map.extent.offset(-correction.x, -correction.y));
            this.suspendExtentHandler = false;
        },

        getCorrection: function (mapExtent) {
            var correction = { x: 0, y: 0 };
            mapExtent = mapExtent || this.map.extent;
            var fudge = (mapExtent.getWidth() / this.map.width) * 25; //Set the fudge factor to the map units equivalent to 25 pixels
            if (mapExtent.xmin > this.mapAreaExtent.xmin - fudge) { correction.x = mapExtent.xmin - this.mapAreaExtent.xmin + fudge; }
            if (mapExtent.ymin > this.mapAreaExtent.ymin + fudge) { correction.y = mapExtent.ymin - this.mapAreaExtent.ymin + fudge; }
            if (mapExtent.xmax < this.mapAreaExtent.xmax + fudge) { correction.x = mapExtent.xmax - this.mapAreaExtent.xmax - fudge; }
            if (mapExtent.ymax < this.mapAreaExtent.ymax + fudge) { correction.y = mapExtent.ymax - this.mapAreaExtent.ymax - fudge; }
            return correction;
        },

        setScaleRanges: function (mapExtent) {
            var layout = this.mapSheetParams.layout;
            var pageSize = this.mapSheetParams.pageSize;
            var mapSize = this.mapSheetParams.mapSize;
            var noTbBorders = this.mapSheetParams.noTbBorders;
            var unitRatio = this.mapSheetParams.unitRatio;
            var maxScale;
            var TempScaleValue;
            mapExtent = mapExtent || this.map.extent;

            //get the maximum scale of the map
            if (layout === 'MAP_ONLY') {
                return;
            }
            if (!isNaN(unitRatio.x) && !isNaN(unitRatio.y)) {
                maxScale = Math.ceil(Math.min(mapExtent.getHeight() / mapSize.height / unitRatio.y,
                                                  mapExtent.getWidth() / mapSize.width / unitRatio.x));
            } else {
                maxScale = this.map.scale;
            }

            // set the ranges on the scale slider
            scaleArray = getValidScales(maxScale, this.mapScales);

            maxScale = scaleArray[0];
            //this code is added for static template. set the scale slider value and scale text box value to maximum scale
            if (scaleArray.length == 1) {
                TempScaleValue = scaleArray[0];
            }
            else {
                if (scaleArray[0] < 750) {
                    TempScaleValue = scaleArray[1];
                }
                else if (scaleArray[1] < 2000) {
                    TempScaleValue = scaleArray[0];
                }
                else if (scaleArray[0] >= 24000 && scaleArray[0] < 2400000 && scaleArray[1] >= 12000) {
                    TempScaleValue = (scaleArray[0] + scaleArray[1]) / 2;
                }
                else if (scaleArray[0] >= 2400000 && scaleArray[0] <= 6000000) {

                    if (scaleArray.length == 6) {
                        TempScaleValue = (scaleArray[0] + scaleArray[1]) / 2;
                    }
                    else {
                        TempScaleValue = scaleArray[0];
                    }
                }
                else {
                    TempScaleValue = scaleArray[1];
                }
            }

            var snapInterval = getSnapInterval(scaleArray);
            var minScale = scaleArray[scaleArray.length - 1];
            var oldScale = this.scaleSliderDijit.get('value');
            var startingScale = getSnapScale(oldScale, scaleArray);
            var discreteScales = ((maxScale - minScale) / snapInterval) + 1;
            this.scaleBoxDijit.set('data-dojo-props', 'constraints:{min:' + minScale.toString() + ',max:' + maxScale.toString() + ',places:0,pattern:"000,000"}');
            this.scaleBoxDijit.set('invalidMessage', 'Invalid scale');
            this.scaleSliderDijit.set('minimum', minScale);
            this.scaleSliderDijit.set('maximum', maxScale);
            this.scaleSliderDijit.set('discreteValues', discreteScales);

            //assign the maximum scale value to slider and scale text box.
            this.scaleSliderDijit.set('value', TempScaleValue);
            this.scaleBoxDijit.set('value', TempScaleValue);

            // The scale labels (number of labels based on number of scales in scaleArray)
            var labels = getLabels(minScale, snapInterval, this.scaleLabelMaps[discreteScales - 1]);
            var sliderWidth = parseInt(domStyle.get(this.scaleSliderDijit.domNode, 'width'), 10);
            var scrollWidth = this.scaleSliderDijit.remainingBar.scrollWidth;
            var leftOffset = (sliderWidth - scrollWidth) / 2 - 1;
            var tickHeight = 2 + this.scaleSliderDijit.sliderHandle.clientHeight / 2;
            if (this.maxScale >= minScale && this.maxScale <= maxScale) {
                lodMaxScalePos = 100 * ((scrollWidth - 1) / scrollWidth - (maxScale - this.maxScale) / (maxScale - minScale));
            } else {
                lodMaxScalePos = null;
            }

            // Delete the ticks and labels
            this.deleteTicksAndLabels();

            // The ticks for each scale increment
            var scaleSliderDom = dom.byId('scaleSlider');
            var ruleNode = domConstruct.create("div", {}, scaleSliderDom, "last");
            this.sliderRule = new HorizontalRule({
                container: "bottomDecoration",
                count: discreteScales,
                ruleStyle: "border-width: thin;",
                style: "width: " + scrollWidth + "px; left: " + leftOffset + "px; height: " + tickHeight + "px;"
            }, ruleNode);
            this.sliderRule.startup();

            //The longer ticks for each scale label
            var ruleNode1 = domConstruct.create("div", {}, scaleSliderDom, "last");
            this.sliderRule1 = new HorizontalRule({
                container: "bottomDecoration",
                count: labels.length,
                ruleStyle: "border-width: thin;",
                style: "width: " + scrollWidth + "px; left: " + leftOffset + "px; height: 3px;"
            }, ruleNode1);
            this.sliderRule1.startup();

            if (lodMaxScalePos) {
                //The red tick for the largest basemap scale
                var ruleNode2 = domConstruct.create("div", {}, scaleSliderDom, "last");
                this.sliderRule2 = new HorizontalRule({
                    container: "bottomDecoration",
                    count: 1,
                    ruleStyle: "border-width: medium; border-color: red; left: " + lodMaxScalePos + "%; height: " + (tickHeight + 3) + "px",
                    style: "width: " + scrollWidth + "px; left: " + leftOffset + "px; height: 5px; top: -14px;"
                }, ruleNode2);
                this.sliderRule2.startup();
            }

            // The scale labels
            var labelsNode = domConstruct.create("div", {}, scaleSliderDom, "last");
            this.sliderLabels = new HorizontalRuleLabels({
                container: "bottomDecoration",
                labels: labels,
                // These width and left settings prevent the labels from causing a horizontal scroll bar.
                style: "width: 84%; left: 7%; height: 1em; font-size: 10px;"
            }, labelsNode);
            this.sliderLabels.startup();

            function getSnapInterval(scales) {
                // This function returns the largest common factor in the scales array.
                // If there is only one scale, return 1; if there are only two scales, return their difference.
                if (scales.length === 1) {
                    return 1;
                } else if (scales.length === 2) {
                    return scales[0] - scales[1];
                }

                // Three or more scales, so find the largest common factor.
                var largestFactor = 1;
                var minScale = scales[scales.length - 1];
                var factors = getPrimeFactors(minScale);
                var failedFactors = [];
                var tryFactor;

                for (var i = 0; i < factors.length; i++) {
                    // if a tryFactor has failed once, don't try it again
                    if (array.indexOf(failedFactors, largestFactor * factors[i]) === -1) {
                        tryFactor = largestFactor * factors[i];
                        // ignore the largest scale - it was calculated, not taken from the list
                        for (var j = 1; j < scales.length - 1; j++) {
                            if (scales[j] % tryFactor !== 0) {
                                break;
                            }
                        }

                        if (j === scales.length - 1) {
                            largestFactor = tryFactor;
                        } else {
                            failedFactors.push(tryFactor);
                        }
                    }
                }

                return largestFactor;
            }

            function getPrimeFactors(value) {
                // This function returns an array of the factors of value.
                // The numbers 1 and value are never in the array, so if value is a prime number, a zero length array is returned.

                var primeFactors = [];
                var newValue = value;
                for (var i = 2; i < value; i++) {
                    while (newValue % i === 0) {
                        newValue = newValue / i;
                        primeFactors.push(i);
                    }

                    if (newValue === 1) {
                        break;
                    }
                }
                return primeFactors;
            }

            function getValidScales(maxScale, mapScales) {
                var validScales = [];

                if (maxScale < mapScales.slice(-1)[0]) {
                    return mapScales.slice(-1);
                }

                var minScale = Math.ceil(maxScale / 7);

                for (var i = 0; i < mapScales.length; i++) {
                    var scale = mapScales[i];
                    if (scale < maxScale) {
                        validScales.push(scale);
                    }
                    if (scale < minScale) {
                        break;
                    }
                }
                return validScales;
            }

            function getSnapScale(scale, scales) {
                var snapScale;
                if (scale === 0) {
                    // Scale is 0; the widget is just being opened.  Return the scale that will set
                    // the sheet graphic to the largest size that does not include the entire map extent.
                    snapScale = scales.length === 1 ? scales[0] : scales[1];
                } else if (array.indexOf(scales, scale) !== -1) {
                    // Scale is one of the values in scales; return scale
                    snapScale = scale;
                } else if (scale > scales[0]) {
                    // Scale is larger than the largest value in scales; return the second largest value in scales
                    snapScale = scales[1];
                } else if (scale < scales[scales.length - 1]) {
                    // Scale is smaller than the smallest value in scales; return the smallest value in scales
                    snapScale = scales[scales.length - 1];
                } else {
                    // Return the value in scales that is closest to scale
                    for (var i = 1; i < scales.length; i++) {
                        if (scale <= scales[i - 1] && scale >= scales[i]) {
                            if (scales[i - 1] - scale > scale - scales[i]) {
                                snapScale = scales[i];
                            } else {
                                snapScale = scales[i - 1];
                            }
                            break;
                        }
                    }
                }
                return snapScale;
            }

            function getLabels(minScale, snapInterval, scaleIndices) {
                var labelArray = [];
                var scale;
                for (var i = 0; i < scaleIndices.length; i++) {
                    scale = minScale + (snapInterval * scaleIndices[i]);
                    labelArray.push(number.format(scale, { pattern: '###,###' }));
                }
                return labelArray;
            }
        },
        deleteTicksAndLabels: function () {
            if (this.sliderRule) {
                this.sliderRule.destroy();
                this.sliderRule = null;
            }
            if (this.sliderRule1) {
                this.sliderRule1.destroy();
                this.sliderRule1 = null;
            }
            if (this.sliderRule2) {
                this.sliderRule2.destroy();
                this.sliderRule2 = null;
            }
            if (this.sliderLabels) {
                this.sliderLabels.destroy();
                this.sliderLabels = null;
            }
        },

        getUnitToMetersFactor: function (unit) {
            switch (unit) {
                case Units.CENTIMETERS: return { x: 0.01, y: 0.01 };
                case Units.INCHES: return { x: 0.0254, y: 0.0254 };
                case Units.MILLIMETERS: return { x: 0.001, y: 0.001 };
                default: return { x: NaN, y: NaN };
            }
        },
        onStateChange: function (reason, newValue) {
            var thisDom, display;
            switch (reason) {
                case 'TITLE_BLOCK':
                    query('#titleInput', this.domNode).style('display', newValue ? '' : 'none');
                    array.forEach(['layoutMetadata', 'layoutMetadataFields', 'includeLegend'], function (item, idx) {
                        display = ['inline', 'inline', 'inline'];
                        thisDom = dom.byId(item);
                        if (thisDom && thisDom.style) {
                            thisDom.style.display = newValue ? display[idx] : 'none';
                        }
                    });
                    break;
                case 'LAYOUT':
                    query('#titleInput', this.domNode).style('display', newValue === 'MAP_ONLY' ? 'none' : '');
                    array.forEach(['scaleBoxRow', 'scaleSliderRow', 'titleBlock', 'showLayout'], function (item, idx) {
                        display = ['table-row', 'table-row', 'inline', 'inline'];
                        thisDom = dom.byId(item);
                        if (thisDom && thisDom.style) {
                            thisDom.style.display = newValue === 'MAP_ONLY' ? 'none' : display[idx];
                        }
                    });
                    // Set the visibility of the preserve scale/extents, map height/width and units, and map sketch.
                    array.forEach(['mapScaleExtent', 'preserve', 'forceScale', 'mapOnlyOptions', 'mapWidthHeight', 'mapSketch', 'mapSketchLegend'], function (item, idx) {
                        display = ['inline', 'inline', 'none', 'inline', 'inline', 'block', 'inline'];  //'forceScale' --> 'table-row'
                        thisDom = dom.byId(item);
                        if (thisDom && thisDom.style) {
                            thisDom.style.display = newValue === 'MAP_ONLY' ? display[idx] : 'none';
                        }
                    });
                    // Set the visibility of the title block options.
                    array.forEach(['layoutMetadata', 'layoutMetadataFields', 'includeLegend'], lang.hitch(this, function (item, idx) {
                        display = ['inline', 'inline', 'inline'];
                        thisDom = dom.byId(item);
                        if (thisDom && thisDom.style) {
                            thisDom.style.display = newValue === 'MAP_ONLY' || !this.titleBlock ? 'none' : display[idx];
                        }
                    }));
                    break;
            }
        },
        _toggleShowLayout: function (show, layoutClicked) {
            var currentWidget = this;
            this.toggleLayoutLayer(show);
            this.togglePanZoomHandlers(show);
            this.toggleMapPanHandlers(show);
            if (show) {
                this.layoutLayer.clear();
                this.drawMapSheet(this.mapAreaCenter);
                this.adjustLayoutToMap(null, this.map.extent);
            } else {
                this.layoutLayer.clear();
                if (layoutClicked) {
                    this.showLayoutDijit.set('value', show);
                    // turn off layoutLayer if the widget is closed
                    if (this.getParent() != null) {
                        if (this.getParent().state === 'closed') {
                            this.toggleLayoutLayer(false);
                        }
                    }
                } else {
                    // This widget was loaded just to populate the Help content, so don't show the layout.
                    this.toggleLayoutLayer(false);
                }
            }
        },
        toggleLayoutLayer: function (visible) {
            this.layoutLayer.visible = visible;
        }
    });

    // Print result dijit
    var PrintResultDijit = declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        widgetsInTemplate: true,
        templateString: printResultTemplate,
        url: null,
        postCreate: function () {
            this.inherited(arguments);
            this.fileHandle.then(lang.hitch(this, '_onPrintComplete'), lang.hitch(this, '_onPrintError'));
        },

        _onPrintComplete: function (data) {
            this.url = undefined;
            if (data.url) {
                this.url = data.url;
                domStyle.set(this.progressBar.domNode, 'display', 'none');
                domStyle.set(this.successNode, 'display', 'inline-block');
                domClass.add(this.resultNode, "printResultHover");
            }
            else if ("undefined" !== typeof (data.results) && 1 == data.results.length &&
                "undefined" !== typeof (data.results[0].value) &&
                "undefined" !== typeof (data.results[0].value.url)) {
                this.url = data.results[0].value.url;
                domStyle.set(this.progressBar.domNode, 'display', 'none');
                domStyle.set(this.successNode, 'display', 'inline-block');
                domClass.add(this.resultNode, "printResultHover");
            } else {
                this._onPrintError(this.nls.printError);
            }
        },

        _onPrintError: function (err) {
            console.log(err);
            domStyle.set(this.progressBar.domNode, 'display', 'none');
            domStyle.set(this.errNode, 'display', 'block');
            domClass.add(this.resultNode, "printResultError");

            domAttr.set(this.domNode, 'title', err.details || err.message || "");
        },

        _openPrint: function () {
            if (this.url !== null) {
                window.open(this.url);
            }
        },
  
    });
    return PrintDijit;
});
