define({
  "serviceURL": "URL del servizio",
  "defaultTitle": "Titolo predefinito",
  "defaultAuthor": "Autore predefinito",
  "defaultCopyright": "Copyright predefinito",
  "defaultFormat": "Formato predefinito",
  "defaultLayout": "Layout predefinito",
  "warning": "Input errato",
  "urlNotAvailable": "Url non disponibile.",
  "notPrintTask": "L'url non è un'attività di stampa",
  "advancedOption": "Mostra opzioni avanzate",
  "ok": "OK",
  "editable": "Modificabile"
});