define({
  "serviceURL": "Tjeneste-URL",
  "defaultTitle": "Standardtitel",
  "defaultAuthor": "Standardforfatter",
  "defaultCopyright": "Standard-copyright",
  "defaultFormat": "Standardformat",
  "defaultLayout": "Standardlayout",
  "warning": "Forkert input",
  "urlNotAvailable": "URL'en er ikke tilgængelig.",
  "notPrintTask": "URL'en er ikke en udskrivningsopgave",
  "advancedOption": "Vis avancerede indstillinger",
  "ok": "OK",
  "editable": "Redigérbar"
});