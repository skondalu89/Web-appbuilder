define({
  "serviceURL": "URL-Сервис",
  "defaultTitle": "Заголовок по умолчанию",
  "defaultAuthor": "Автор по умолчанию",
  "defaultCopyright": "Copyright по умолчанию",
  "defaultFormat": "Формат по умолчанию",
  "defaultLayout": "Компоновка по умолчанию",
  "warning": "Входные данные не корректны",
  "urlNotAvailable": "URL-адрес недоступен",
  "notPrintTask": "URL-адрес не является заданием печати",
  "advancedOption": "Показать дополнительные опции",
  "ok": "OK",
  "editable": "Редактируемые"
});