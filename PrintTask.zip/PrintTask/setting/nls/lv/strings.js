define({
  "serviceURL": "Servisa URL",
  "defaultTitle": "Noklusējuma virsraksts",
  "defaultAuthor": "Noklusējuma autors",
  "defaultCopyright": "Noklusējuma autortiesības",
  "defaultFormat": "Noklusējuma formāts",
  "defaultLayout": "Noklusējuma izkārtojums",
  "warning": "Nepareiza ievade",
  "urlNotAvailable": "Vietrādis URL nav pieejams",
  "notPrintTask": "Vietrādis URL nav drukas uzdevums",
  "advancedOption": "Rādīt papildu opcijas",
  "ok": "Labi",
  "editable": "Rediģējams"
});