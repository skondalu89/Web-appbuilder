define({
  "serviceURL": "Szolgáltatás URL-címe",
  "defaultTitle": "Alapértelmezett cím",
  "defaultAuthor": "Alapértelmezett szerző",
  "defaultCopyright": "Alapértelmezett szerzői jog",
  "defaultFormat": "Alapértelmezett formátum",
  "defaultLayout": "Alapértelmezett elrendezés",
  "warning": "Helytelen adatbevitel",
  "urlNotAvailable": "Az URL nem érhető el",
  "notPrintTask": "Az URL nem nyomtatási feladat",
  "advancedOption": "Haladó beállítások mutatása",
  "ok": "OK",
  "editable": "Szerkeszthető"
});