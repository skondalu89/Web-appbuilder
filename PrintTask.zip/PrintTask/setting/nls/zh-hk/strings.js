define({
  "serviceURL": "服務 URL",
  "defaultTitle": "預設標題",
  "defaultAuthor": "預設作者",
  "defaultCopyright": "預設版權",
  "defaultFormat": "預設格式",
  "defaultLayout": "預設版面配置",
  "warning": "輸入不正確",
  "urlNotAvailable": "url 無法使用",
  "notPrintTask": "url 不是列印任務",
  "advancedOption": "顯示進階選項",
  "ok": "確定",
  "editable": "可編輯"
});