define({
  "serviceURL": "URL של השירות",
  "defaultTitle": "כותרת ברירת מחדל",
  "defaultAuthor": "מחבר ברירת מחדל",
  "defaultCopyright": "זכויות יוצרים ברירת מחדל",
  "defaultFormat": "פורמט ברירת מחדל",
  "defaultLayout": "פריסת ברירת מחדל",
  "warning": "קלט לא תקין",
  "urlNotAvailable": "כתובת ה-URL אינה זמינה",
  "notPrintTask": "כתובת ה-URL אינה משימת הדפסה",
  "advancedOption": "הצג אפשרויות מתקדמות",
  "ok": "אישור",
  "editable": "ניתן לעריכה"
});