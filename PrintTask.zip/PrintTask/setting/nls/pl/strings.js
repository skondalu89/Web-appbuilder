define({
  "serviceURL": "Adres URL usługi",
  "defaultTitle": "Tytuł domyślny",
  "defaultAuthor": "Autor domyślny",
  "defaultCopyright": "Domyślne prawa autorskie",
  "defaultFormat": "Format domyślny",
  "defaultLayout": "Kompozycja domyślna",
  "warning": "Nieprawidłowe dane wejściowe",
  "urlNotAvailable": "Adres URL jest niedostępny",
  "notPrintTask": "Nie jest to adres URL zadania wydruku",
  "advancedOption": "Pokaż opcje zaawansowane",
  "ok": "OK",
  "editable": "Edytowalne"
});