define({
  "serviceURL": "सेवा URL",
  "defaultTitle": "डिफ़ॉल्ट शीर्षक",
  "defaultAuthor": "डिफ़ॉल्ट लेखक",
  "defaultCopyright": "डिफ़ॉल्ट कॉपीराइट",
  "defaultFormat": "डिफ़ॉल्ट फॉर्मेट",
  "defaultLayout": "डिफ़ॉल्ट रूपरेखा",
  "warning": "गलत इनपुट",
  "urlNotAvailable": "url उपलब्ध नहीं है।",
  "notPrintTask": "url एक प्रिंट कार्य नहीं है",
  "advancedOption": "उन्नत विकल्प दिखाएँ",
  "ok": "ठीक है",
  "editable": "संशोधन योग्य"
});