define({
  "serviceURL": "URL del servei",
  "defaultTitle": "Títol per defecte",
  "defaultAuthor": "Autor per defecte",
  "defaultCopyright": "Drets d'autor per defecte",
  "defaultFormat": "Format per defecte",
  "defaultLayout": "Disseny per defecte",
  "warning": "Entrada incorrecta",
  "urlNotAvailable": "La URL no està disponible",
  "notPrintTask": "La URL no és una tasca d'impressió",
  "advancedOption": "Mostra les opcions avançades",
  "ok": "D'acord",
  "editable": "Editable"
});