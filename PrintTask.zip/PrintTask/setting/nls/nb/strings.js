define({
  "serviceURL": "Tjeneste-URL",
  "defaultTitle": "Standardtittel",
  "defaultAuthor": "Standard forfatter",
  "defaultCopyright": "Standard opphavsrett",
  "defaultFormat": "Standardformat",
  "defaultLayout": "Standardoppsett",
  "warning": "Feil inndata",
  "urlNotAvailable": "URL-en er ikke tilgjengelig",
  "notPrintTask": "URL-en er ikke en utskriftsoppgave",
  "advancedOption": "Vis avanserte alternativer",
  "ok": "OK",
  "editable": "Redigerbar"
});