define({
  "serviceURL": "服务 URL",
  "defaultTitle": "默认标题",
  "defaultAuthor": "默认作者",
  "defaultCopyright": "默认版权",
  "defaultFormat": "默认格式",
  "defaultLayout": "默认布局",
  "warning": "输入不正确",
  "urlNotAvailable": "url 不可用。",
  "notPrintTask": "此 url 不是一个打印任务",
  "advancedOption": "显示高级选项",
  "ok": "确定",
  "editable": "可编辑"
});