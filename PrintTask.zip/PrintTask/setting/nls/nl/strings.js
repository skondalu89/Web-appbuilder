define({
  "serviceURL": "Service-URL",
  "defaultTitle": "Standaardtitel",
  "defaultAuthor": "Standaardauteur",
  "defaultCopyright": "Standaard copyright",
  "defaultFormat": "Standaardindeling",
  "defaultLayout": "Standaardlay-out",
  "warning": "Onjuiste invoer",
  "urlNotAvailable": "De url is niet beschikbaar",
  "notPrintTask": "De url is geen afdruktaak",
  "advancedOption": "Geavanceerde opties weergeven",
  "ok": "OK",
  "editable": "Bewerkbaar"
});