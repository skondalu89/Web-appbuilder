define({
  "serviceURL": "Service URL",
  "defaultTitle": "ชื่อตามค่าเริ่มต้น",
  "defaultAuthor": "ผู้เขียนตามค่าเริ่มต้น",
  "defaultCopyright": "ลิขสิทธิ์ตามค่าเริ่มต้น",
  "defaultFormat": "รูปแบบตามค่าเริ่มต้น",
  "defaultLayout": "เค้าโครงเริ่มต้น",
  "warning": "ข้อมูลนำเข้าไม่ถูกต้อง",
  "urlNotAvailable": "URL ที่ไม่สามารถใช้ได้",
  "notPrintTask": "URL ที่ไม่สามารถพิมพ์ได้",
  "advancedOption": "แสดงทางเลือก",
  "ok": "ตกลง",
  "editable": "ที่สามารถแก้ไขได้"
});