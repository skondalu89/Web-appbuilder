define({
  "serviceURL": "URL du service",
  "defaultTitle": "Titre par défaut",
  "defaultAuthor": "Auteur par défaut",
  "defaultCopyright": "Copyright par défaut",
  "defaultFormat": "Format par défaut",
  "defaultLayout": "Mise en page par défaut",
  "warning": "Entrée incorrecte",
  "urlNotAvailable": "L'URL n'est pas disponible",
  "notPrintTask": "L'URL n'est pas une tâche d'impression",
  "advancedOption": "Afficher les options avancées",
  "ok": "OK",
  "editable": "Modifiable"
});