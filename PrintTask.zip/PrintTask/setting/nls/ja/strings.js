define({
  "serviceURL": "サービスの URL",
  "defaultTitle": "デフォルトのタイトル",
  "defaultAuthor": "デフォルトの作成者",
  "defaultCopyright": "デフォルトの著作権",
  "defaultFormat": "デフォルトの形式",
  "defaultLayout": "デフォルトのレイアウト",
  "warning": "不正な入力",
  "urlNotAvailable": "URL は利用できません。",
  "notPrintTask": "URL は印刷タスクではありません。",
  "advancedOption": "高度な設定を表示",
  "ok": "OK",
  "editable": "編集可能"
});