define({
  "serviceURL": "Paslaugos URL",
  "defaultTitle": "Numatytasis pavadinimas",
  "defaultAuthor": "Numatytasis autorius",
  "defaultCopyright": "Numatytosios autoriaus teisės",
  "defaultFormat": "Numatytasis formatas",
  "defaultLayout": "Numatytasis maketas",
  "warning": "Klaidinga įvestis",
  "urlNotAvailable": "URL nepasiekiamas",
  "notPrintTask": "URL nėra spausdinimo užduotis",
  "advancedOption": "Rodyti išplėstinius nustatymus",
  "ok": "Gerai",
  "editable": "Redaguojama"
});