define({
  "serviceURL": "URL usluge",
  "defaultTitle": "Zadani naslov",
  "defaultAuthor": "Zadani autor",
  "defaultCopyright": "Zadano autorsko pravo",
  "defaultFormat": "Zadani format",
  "defaultLayout": "Zadani izgled",
  "warning": "Neispravan unos",
  "urlNotAvailable": "URL nije dostupan.",
  "notPrintTask": "URL nije zadatak ispisa",
  "advancedOption": "Prikaži napredne opcije",
  "ok": "U redu",
  "editable": "Može se uređivati"
});