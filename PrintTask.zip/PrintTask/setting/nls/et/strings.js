define({
  "serviceURL": "Teenuse URL",
  "defaultTitle": "Vaikimisi pealkiri",
  "defaultAuthor": "Vaikimisi autor",
  "defaultCopyright": "Vaikimisi autoriõigus",
  "defaultFormat": "Vaikimisi vorming",
  "defaultLayout": "Vaikimisi paigutus",
  "warning": "Vale sisend",
  "urlNotAvailable": "URL pole kättesaadav.",
  "notPrintTask": "URL pole printimistoiming",
  "advancedOption": "Näita täiustatud valikuid",
  "ok": "OK",
  "editable": "Muudetav"
});