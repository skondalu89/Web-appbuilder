define({
  "serviceURL": "URL de Serviço",
  "defaultTitle": "Título padrão",
  "defaultAuthor": "Autor padrão",
  "defaultCopyright": "Direitos autorais padrão",
  "defaultFormat": "Formato padrão",
  "defaultLayout": "Layout padrão",
  "warning": "Entrada incorreta",
  "urlNotAvailable": "A url não está disponível",
  "notPrintTask": "A url não é uma tarefa de impressão",
  "advancedOption": "Mostrar opções avançadas",
  "ok": "OK",
  "editable": "Editável"
});