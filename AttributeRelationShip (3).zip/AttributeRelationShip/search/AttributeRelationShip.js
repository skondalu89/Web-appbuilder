/// <reference path="../Widget.js" />
/// <reference path="../Widget.js" />
/// <reference path="../Widget.js" />
/// <reference path="templates/Widget1.html" />
define([
    "dojo/parser", "esri/request", 'dojo/_base/array', "dojo/_base/window", //"./css/css/js/select2fullmin","./css/css/css/select2min",
    "esri/tasks/RelationshipQuery", "esri/graphic", "esri/geometry/Point",
    "esri/symbols/SimpleFillSymbol", "esri/renderers/SimpleRenderer",
    "esri/symbols/SimpleMarkerSymbol", "esri/symbols/SimpleLineSymbol", "esri/symbols/CartographicLineSymbol",
    "dojo/store/Observable", "dojo/_base/array", "esri/config", "esri/geometry/normalizeUtils", "esri/tasks/BufferParameters","dojo/dom-construct",
    "dojo/dom-style", "esri/toolbars/draw", "dojo/promise/all",
    "dijit/tree/ObjectStoreModel", "dijit/Tree", "dijit/registry",
    "dojo/dom", 'jimu/BaseWidget',
    "jimu/LayerInfos/LayerInfos",
    "dojo/store/Memory", "dijit/form/ComboBox",
    "dijit/form/FilteringSelect",
    "dojo/_base/Color",
    "dojo/Evented",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/has", // feature detection
    "esri/kernel", // esri namespace
    "dijit/_WidgetBase",
    "dijit/a11yclick", // Custom press, release, and click synthetic events which trigger on a left mouse click, touch, or space/enter keyup.
    "dijit/_TemplatedMixin",
    'dijit/_WidgetsInTemplateMixin',
    "dojo/on",
    "dojo/Deferred",
    "jimu/dijit/Message", "dojo/mouse",
    "esri/tasks/query",
    "dojo/text!./templates/AttributeRelationShip.html",
    "dojo/query", "esri/tasks/GeometryService",
    "esri/tasks/QueryTask", "esri/layers/FeatureLayer",
    "dijit/Menu", "dijit/MenuItem", "dijit/CheckedMenuItem", "dijit/MenuSeparator",
    "dijit/PopupMenuItem",
    'jimu/dijit/Popup', "dijit/form/Button",
    'dojo/domReady!', "dijit/form/TextBox" 

],
    function (
        parser, esriRequest, array, win, RelationshipQuery, Graphic, Point, SimpleFillSymbol, SimpleRenderer, SimpleMarkerSymbol, SimpleLineSymbol, CartographicLineSymbol, Observable,
        array, esriConfig, normalizeUtils, BufferParameters,domConstruct,
        domStyle, Draw, all, ObjectStoreModel, Tree, registry, dom, BaseWidget, LayerInfos, Memory, ComboBox,FilteringSelect, Color, Evented, declare, lang, has, esriNS, _WidgetBase, a11yclick, _TemplatedMixin, _WidgetsInTemplateMixin,
        on, Deferred, Message, mouse, Query, template, query, GeometryService, QueryTask, FeatureLayer, Menu, MenuItem, CheckedMenuItem, MenuSeparator, PopupMenuItem, Popup, Button, _dndSelector,
        dndSource
    ) {
        var Widget = declare([BaseWidget, _WidgetBase, _TemplatedMixin, Evented], {
            baseClass: 'jimu-widget-AttributeQuery',
            urlObj: null,
            fieldTypes: [],
            layerHasRelship: null,
            layerRelationships: [],
            DisplayattrObj: [],
            BufferData: [],
            relatedidObj: [],
            Treestore: [],
            InitialExtent: null,
            LayerTotObj: [],
            LayerDomains: [],
            getSelectedObj: null,
            templateString: template,
            postCreate: function () {
                this.inherited(arguments);
                var currentWidget = this;
            },
            // start widget. called by user
            startup: function () {
                //$('.select2').select2();
               // document.getElementsByClassName(".select2").select2();
                var currentWidget = this;
                domStyle.set(dom.byId('QueryLoader'), "display", "block");
                if (currentWidget.wabWidget.map.itemInfo.itemData.operationalLayers.lendgth == 0) {
                    currentWidget.wabWidget.FeatureSelectionTab.popAlert("Operation Layers not found");
                    domStyle.set(dom.byId('QueryLoader'), "display", "none");
                    return;
                };
                console.log("attribute relations", currentWidget.wabWidget.LayerTotObj);
                if (currentWidget.wabWidget.LayerTotObj != null) {
                    currentWidget.LayerTotObj = currentWidget.wabWidget.LayerTotObj;
                   // currentWidget.loadMapServices(currentWidget.wabWidget.LayerTotObj);
                }
            },
            OnFeatureChange: function () {
                try {
                    var currentWidget = this;
                    var object = currentWidget.LayerTotObj;
                    var aldataa = [], searchdata=[];
                   // dojo.empty(currentWidget.selectedLayer)
                    domStyle.set(dom.byId('content'), "display", "none");
                    //dojo.place("<option value=''>Select Layers</option>", currentWidget.selectedLayer, 0);
                    var selectedfeatureType = document.getElementById("selectedFeatureType").value;
                    if (selectedfeatureType == "All") {
                        for (var al = 0; al < object.length; al++) {                          
                            if (object[al].fields != null) {
                                aldataa.push(object[al].name);
                            }
                            searchdata.push({ id: al, Name: object[al].name });
                        }                     
                    }
                    else if (selectedfeatureType == "Relations") {
                        for (var al = 0; al < object.length; al++) {
                            if (object[al].isrelationsExist == true) {
                                if (object[al].fields != null) {
                                    aldataa.push(object[al].name);
                                }                               
                                searchdata.push({ id: al, Name: object[al].name });
                             }
                        }                      
                    }
                    else if (selectedfeatureType == "Tables") {
                        for (var al = 0; al < object.length; al++) {
                            if (object[al].type == "Table" && object[al].isrelationsExist ==false) {
                                if (object[al].fields != null) {
                                    aldataa.push(object[al].name);
                                }                                
                                searchdata.push({ id: al, Name: object[al].name });
                            }
                        }                       
                    }
                    else if (selectedfeatureType == "Layers") {
                        for (var al = 0; al < object.length; al++) {
                            if (object[al].type == "Feature Layer" && object[al].isrelationsExist == false) {
                                if (object[al].fields != null) {
                                    aldataa.push(object[al].name);
                                }                              
                                searchdata.push({ id: al, Name: object[al].name });
                            }
                        }                       
                    }                   
                   
                    dijit.byId("selected").params.store.data = searchdata;                 
                    dijit.byId("selected").displayedValue= searchdata[0].Name;
                    currentWidget.Layerchange(searchdata[0].Name);
                } catch (e) {
                    console.log(e);
                }
            },
            //to load services in combo dropdown
            loadMapServices: function (object) {
                try {                   
                    var currentWidget = this;
                    document.getElementById("selectedFeatureType").selectedIndex = 0;
                    var aldataa = [],searchdata=[];
                   // var select = dijit.byId("selected").value;
                    for (var al = 0; al < object.length; al++) {
                        if (object[al].type != undefined) {
                            if (object[al].type.toUpperCase() == "FEATURE LAYER" || object[al].type.toUpperCase() == "ANNOTATION SUBLAYER" || object[al].type.toUpperCase() == "ANNOTATION LAYER" || object[al].type.toUpperCase() == "GROUP LAYER" && object[al].isrelationsExist == false) {
                                aldataa.push(object[al].name);
                                searchdata.push({ id: al, Name: object[al].name });
                            }
                        }
                    }
                    var combo=new dijit.form.ComboBox({
                        id: "selected",
                        store: new Memory({ data: searchdata }),
                        autoComplete: true,
                        query: { Name: /.*/ },
                        style: "width: 150px;",
                        required: true,
                        searchAttr: "Name",
                        value:searchdata[0].Name,
                        onChange: function (city) {
                            console.log("combobox onchange ", city, this.item);
                            var SelectedName = this.item.Name;
                            currentWidget.Layerchange(SelectedName);
                        }
                    }, "selectedLayer").startup();                  
                   // document.getElementById("selectedLayer").selectedIndex = 0;
                    domStyle.set(dom.byId('QueryLoader'), "display", "none");
                    currentWidget.Layerchange(searchdata[0].Name);
                }
                catch (e) {
                    console.log(e);
                }
            },
            /////Dropdown Layer on chenge 
            Layerchange: function (LayerName) {
                try {
                    var currentWidget = this, codedValueDomain = [];
                    dojo.empty("AttrTableid");
                    var tablebody = document.getElementById('tbodyid');
                    if (tablebody != null) {
                        dojo.destroy("tbodyid");
                        tablebody.innerHTML = "";
                    }
                    //  dojo.byId("resultCount").innerText = "";
                    var layerarray = [];
                    var layername = LayerName;
                    if (layername == "") {
                        domStyle.set(dom.byId('content'), "display", "none");
                    }
                   // dojo.byId("resultCount").innerText = "";
                   // dojo.byId("Relations_Count").innerText = "";
                    currentWidget.layerHasRelship = false;
                    currentWidget.wabWidget.map.graphics.clear();
                    currentWidget.layerRelationships = [];
                    currentWidget.fieldTypes = [];
                    var AttributTree = dijit.byId("SelectFeat");
                    if (AttributTree) {
                        AttributTree.destroyRecursive();
                    }
                    query(".gridtable .fieldsBody").style("display", "block");
                    if (layername.length = 0) {
                        currentWidget.wabWidget.FeatureSelectionTab.popAlert("Please select the Layer");
                        return;
                    }
                    var layerObj = currentWidget.LayerTotObj.find(x=>x.name == layername);

                    for (var i = 0; i < currentWidget.LayerTotObj.length; i++) {
                        if (layername == currentWidget.LayerTotObj[i].name) {
                            for (var V = 0; V < currentWidget.LayerTotObj[i].fields.length; V++) {
                                if (currentWidget.LayerTotObj[i].fields[V].domain != null) {
                                    var displayDomainobject = { "codedValues": currentWidget.LayerTotObj[i].fields[V].domain, "FieldName": currentWidget.LayerTotObj[i].fields[V].name };
                                    codedValueDomain.push(displayDomainobject)
                                }
                            }
                            currentWidget.urlObj = currentWidget.LayerTotObj[i].url
                            if (currentWidget.LayerTotObj[i]["relations"] != undefined) {
                                currentWidget.layerHasRelship = true;
                                currentWidget.relatedidObj = currentWidget.LayerTotObj[i].relations;
                                for (var j = 0; j < currentWidget.LayerTotObj[i].relations.length; j++) {
                                    var obj = {
                                        name: currentWidget.LayerTotObj[i].relations[j].name,
                                        relatedTableId: currentWidget.LayerTotObj[i].relations[j].relatedTableId
                                    };
                                    currentWidget.layerRelationships.push(obj);
                                }
                            }
                            for (var k = 0; k < currentWidget.LayerTotObj[i].fields.length; k++) {
                                if (currentWidget.LayerTotObj[i].fields[k].type != "esriFieldTypeGeometry") {
                                    layerarray.push(currentWidget.LayerTotObj[i].fields[k].alias.toUpperCase());
                                    var obj = { Field: currentWidget.LayerTotObj[i].fields[k].name, Type: currentWidget.LayerTotObj[i].fields[k].type, alias: currentWidget.LayerTotObj[i].fields[k].alias.toUpperCase() };
                                    currentWidget.fieldTypes.push(obj);
                                };
                            };
                            currentWidget.buildTable(layerarray, layerObj);
                        }

                    }
                }
                catch (e) {
                    console.log(e);
                }
            },
            buildTable: function (data, layerObj) {
                try {
                    domStyle.set(dom.byId('AttributeFinder'), "display", "block");
                    domStyle.set(dom.byId('content'), "display", "block");
                    var currentWidget = this;
                    var tablebody = document.getElementById('tbodyid');
                    if (tablebody != null) {
                        dojo.destroy("tbodyid");
                        tablebody.innerHTML = "";
                    }
                    var table = query(".gridtable");
                    var tbody = '<tbody class="fieldsBody" id="tbodyid">'
                    var row = document.getElementsByClassName('fieldsBody')[0];
                    if (row) {
                        row.parentNode.removeChild(row);
                    }
                    if (layerObj.fields.length > 0) {
                        for (var i = 0; i < layerObj.fields.length; i++) {
                            if (layerObj.fields[i].type == "esriFieldTypeGeometry")
                                continue;
                            if (layerObj.fields[i].name.toUpperCase() == "SHAPE.LENGTH") continue;
                            tbody = tbody + '<tr> <td>' + layerObj.fields[i].alias + '</td>';
                            if (layerObj.fields[i].name == layerObj.typeIdField) {
                                var selectdomain = document.createElement("selectdomain" + i);
                                for (var obj = 0; obj < layerObj.domaintypes.length; obj++) {
                                    var option = document.createElement("option");
                                    option.value = layerObj.domaintypes[obj].id;//.codedValues[drop].code;
                                    option.innerHTML = layerObj.domaintypes[obj].name; //layerObj.domaintypes.codedValues[drop].name;
                                    selectdomain.appendChild(option);
                                }
                                tbody = tbody + '<td><select calss="SubtypeFiels"  id="DropdownSubtype"><option value=""></option> <option value="' + selectdomain.outerHTML + '"></option></select></td></tr>';

                            }
                            else if (layerObj.fields[i].domain != null) {
                                if (layerObj.fields[i].domain.codedValues) {
                                    var selectList = document.createElement("select" + i);
                                    for (var drop = 0; drop < layerObj.fields[i].domain.codedValues.length; drop++) {
                                        var option = document.createElement("option");
                                        option.value = layerObj.fields[i].domain.codedValues[drop].code;
                                        option.innerHTML = layerObj.fields[i].domain.codedValues[drop].name;
                                        selectList.appendChild(option);
                                    }
                                    tbody = tbody + '<td><select calss="domainfields"  id="Dropdowns"><option value=""></option> <option value="' + selectList.outerHTML + '"></option></select></td></tr>';

                                } else {
                                    tbody = tbody + '<td><input class="searchBox" type="text" placeholder="null" ></td></tr>';

                                }

                            } else {
                                tbody = tbody + '<td><input id="' + layerObj.fields[i].alias + '" class="searchBox" type="text" placeholder="null" ></td></tr>';

                            }
                        }
                        tbody = tbody + '</tbody>';
                        table.append(tbody);
                    }
                }
                catch (e) {
                    console.log(e);
                }
            },
            /////////////// Find Selected Layer Data to build Treeview 
            doquery: function () {
                try {
                    var currentWidget = this;
                    var table = query(".gridtable");
                    var loopFlag = true;
                    var array = [], Searchval = [];
                    var getlayername = dijit.byId("selected").value;//dojo.byId(currentWidget.selectedLayer).value;
                    if (getlayername != "") {
                        for (var j = 0; j < dojo.query(".gridtable > tbody > tr").length; j++) {
                            var td = dojo.query(".gridtable > tbody > tr")[j];
                            if (td != null) {
                                var field = td.cells[0].innerHTML;
                                var searchvalue = td.cells[1].childNodes[0].value;
                                if (searchvalue != "" && searchvalue != "Null") {
                                    loopFlag = false;
                                    array.push({ searchstring: searchvalue, fieldName: field })
                                }
                            }
                        }
                        if (array.length > 0) {
                            var searchvalue = array;
                            var whereCond = "";
                            for (var i = 0; i < searchvalue.length; i++) {
                                if (searchvalue[i].searchstring != "" && searchvalue[i].searchstring != null && searchvalue[i].searchstring != undefined) {
                                    loopFlag = false;
                                    for (var k = 0; k < currentWidget.fieldTypes.length; k++) {
                                        var item = currentWidget.fieldTypes[k];
                                        if (currentWidget.fieldTypes[k].alias.toUpperCase() == searchvalue[i].fieldName.toUpperCase()) {
                                            searchvalue[i].fieldName = currentWidget.fieldTypes[k].Field;
                                            if (item.Type == "esriFieldTypeOID" || item.Type == "esriFieldTypeInteger" || item.Type == "esriFieldTypeDouble") {
                                                if (i == searchvalue.length - 1) {
                                                    whereCond = whereCond + searchvalue[i].fieldName + "=" + searchvalue[i].searchstring;
                                                }
                                                else {
                                                    whereCond = whereCond + searchvalue[i].fieldName + " = " + searchvalue[i].searchstring + " " + "OR" + " ";
                                                }
                                            }
                                            else {
                                                if (i == searchvalue.length - 1) {
                                                    whereCond = whereCond + "Upper(" + searchvalue[i].fieldName + ") " + " LIKE '%" + searchvalue[i].searchstring.toUpperCase() + "%'";
                                                }
                                                else {
                                                    whereCond = whereCond + "Upper(" + searchvalue[i].fieldName + ") " + " LIKE '%" + searchvalue[i].searchstring.toUpperCase() + "%'" + "OR" + " ";
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (loopFlag) {
                            currentWidget.wabWidget.FeatureSelectionTab.popAlert("Enter search field");
                            return;
                        }
                        currentWidget.doFind(whereCond);
                    }
                    else {
                        currentWidget.wabWidget.FeatureSelectionTab.popAlert("Choose search Layer");
                        return;
                    }
                }
                catch (e) {
                    console.log(e);
                }
            },
            destroy: function () {
                this.inherited(arguments);
            },
         
            //to find the selected services features
            doFind: function (querystring) {
                try {                   
                    var currentWidget = this;
                    domStyle.set(dom.byId('QueryLoader'), "display", "block");                   
                    currentWidget.wabWidget.map.graphics.clear();                  
                    var query = new Query();
                    //dojo.byId("resultCount").innerText = "";
                    //dojo.byId("Relations_Count").innerText = "";
                    var queryTask = new QueryTask(currentWidget.urlObj);
                    query.outSpatialReference = currentWidget.wabWidget.map.spatialReference;
                    query.returnGeometry = true;
                    query.outFields = ["*"];
                    query.where = querystring;
                    queryTask.execute(query, lang.hitch(currentWidget, currentWidget.showResults), lang.hitch(currentWidget, currentWidget.errorBack));

                } catch (e) {
                    console.log(e);
                }
            },
            showResults: function (results) {
                try {
                    dojo.empty("AttrTableid");
                    var currentWidget = this;
                    currentWidget.treeArray = [];
                    currentWidget.DisplayattrObj = [];
                    if (results.features.length > 0) {
                        domStyle.set(dom.byId('AttributeFinder'), "display", "block");
                       // domStyle.set(dom.byId('AttributeInfotab'), "display", "none");
                        //document.getElementById("Static_Img").style.display = "none";
                        if (document.getElementsByClassName('tab-item-div')[1].label == "Attribute Viewer") {
                            document.getElementsByClassName("tab-item-td")[1].className += " jimu-state-active";
                            domStyle.set(dom.byId('uniqName_9_0'), "display", "block");
                            domStyle.set(dom.byId('uniqName_0_0'), "display", "none");
                            domStyle.set(dom.byId('uniqName_9_0'), "opacity", "1");
                            document.getElementsByClassName("tab-item-td")[0].className = "tab-item-td";
                        }
                        var geometry, symbol;
                        currentWidget.wabWidget.map.graphics.clear();
                        queryTaskList = [];
                        var array = [], geometryObj = [];
                        currentWidget.Treestore = [];
                        var getlayername = dijit.byId("selected").value;// dojo.byId(currentWidget.selectedLayer).value;
                       // dojo.byId("resultCount").innerText = results.features.length;
                        geometryObj.push({ name: getlayername, geomtryType: results.geometryType });
                        array.push({ id: "Parentgroup", name: "Results" })
                        var layerparent = { id: getlayername, name: getlayername, parent: "Parentgroup" }
                        array.push(layerparent);                      
                        var layerObj = currentWidget.LayerTotObj.find(x=>x.name == getlayername);
                        var primaryKeyColumn = "";
                        for (var x = 0; x < results.fields.length; x++) {
                            if (results.fields[x].type == "esriFieldTypeOID") {
                                primaryKeyColumn = results.fields[x].name;
                                break;
                            }
                        }
                        var displayname;
                        if (results.displayFieldName == undefined) {
                            displayname = results.objectIdFieldName || results.objectIdFieldName;
                        } else {
                            displayname = results.displayFieldName || results.DISPLAYFIELDNAME;
                        }
                        for (var j = 0; j < results.features.length; j++) {
                            geometry = results.features[j].geometry;
                            var esritype = results.geometryType;
                            currentWidget.wabWidget.map.graphics.add(new Graphic(geometry, symbol));
                            var displayField = results.features[j].attributes[primaryKeyColumn];
                            var displayfieldObj = { id: getlayername + displayField, name: displayname + ":" + displayField, parentname: "OBJECTID:" + displayField, parent: getlayername, Name: getlayername, attributes: results.features[j].attributes, geomtype: geometry, fields: layerObj.fields, typeIdField: layerObj.typeIdField, domainValues: layerObj.domaintypes };
                            var Dataobject = { name: "OBJECTID:" + displayField, attr: results.features[j], geomtype: results.geometryType, layername: getlayername, Fields: layerObj.fields };
                            currentWidget.DisplayattrObj.push(Dataobject);
                            if (layerObj.relations != undefined || layerObj.relations != null) {
                               // dojo.byId("Relations_Count").innerText = layerObj.relations.length;
                                if (layerObj.type == "Feature Layer") {
                                    currentWidget.relatedidObj = layerObj.relations;
                                    for (var k = 0; k < layerObj.relations.length; k++) {
                                        var displayrelationObj = { objectId: displayField, id: layerObj.relations[k].name + displayField, name: layerObj.relations[k].name, parent: getlayername + displayField, layername: getlayername, hasrelationship: true, fields: layerObj.fields, typeIdField: layerObj.typeIdField, domainValues: layerObj.domaintypes }
                                        array.push(displayrelationObj);
                                    }
                                }
                            }
                            else if (layerObj.isrelationsExist == true && layerObj.type == "Table") {
                                array.push(displayfieldObj);
                            }
                            else if (layerObj.isrelationsExist == true && layerObj.type == "Feature Layer") {
                                array.push(displayfieldObj);
                            }
                            if (layerObj.isrelationsExist == false)
                                array.push(displayfieldObj);
                        }                      
                        
                        currentWidget.wabWidget.FeatureSelectionTab.buildTree(array, geometryObj,"SearchValue");
                    }
                    else {
                        currentWidget.wabWidget.FeatureSelectionTab.popAlert("No records found");
                        domStyle.set(dom.byId('QueryLoader'), "display", "none");
                        return;
                    }
                }
                catch (e) {
                    console.log(e);
                }
            },
            errorBack: function (error) {
                var currentWidget = this;
                currentWidget.wabWidget.FeatureSelectionTab.popAlert("No records found");
                domStyle.set(dom.byId('QueryLoader'), "display", "none");
                return;
            },
            /////clear all the data///
            clearTree: function () {
                try {
                    var currentWidget = this;
                    currentWidget.wabWidget.FeatureSelectionTab.clearTree("AttributeRelation");
                }
                catch (e) {
                    console.log(e);
                }
            },
            //popAlert: function (message) {
            //    new Message({
            //        titleLabel: "Attribute Query",
            //        message: message
            //    });
            //},
        });
        return Widget;
    });