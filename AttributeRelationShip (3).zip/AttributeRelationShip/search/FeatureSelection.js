define(['dojo/_base/declare', 'jimu/BaseWidget', "dojo/text!./templates/FeatureSelection.html",
    "esri/toolbars/draw", "esri/symbols/SimpleLineSymbol", "dijit/Toolbar", "esri/toolbars/navigation",
        "esri/symbols/SimpleFillSymbol", "esri/graphic", "esri/Color", "dojo/dom", "dojo/on",
        "esri/request", "dojo/_base/lang", "esri/tasks/query", "esri/tasks/QueryTask", "dojo/Deferred",
        "dojo/promise/all", "dojo/_base/connect", "dojo/store/Observable", "esri/tasks/GeometryService", "esri/symbols/PictureMarkerSymbol",
        "esri/geometry/normalizeUtils", "esri/tasks/BufferParameters", 'dojo/_base/array',
    "dojo/dom-style", "dijit/tree/ObjectStoreModel", "dijit/Tree", "dojo/store/Memory", "dojo/query",
      "esri/symbols/SimpleMarkerSymbol", "esri/symbols/SimpleLineSymbol", "esri/layers/FeatureLayer",
      "esri/tasks/RelationshipQuery", "esri/geometry/Point", "jimu/dijit/Message", "dojo/dom-style",
       "dijit/Menu", "dijit/MenuItem", "dijit/CheckedMenuItem", "dijit/MenuSeparator",
    "dijit/PopupMenuItem",
        "dojo/domReady!"],
  function (declare, BaseWidget, template, Draw, SimpleLineSymbol, Toolbar, Navigation, SimpleFillSymbol, Graphic,
        Color, dom, on, esriRequest, lang, Query, QueryTask, Deferred, all, connect, Observable, GeometryService, PictureMarkerSymbol, normalizeUtils, BufferParameters, array,
        domStyle, ObjectStoreModel, Tree, Memory, query, SimpleMarkerSymbol, SimpleLineSymbol,
        FeatureLayer, RelationshipQuery, Point, Message, domStyle, Menu, MenuItem, CheckedMenuItem, MenuSeparator,
        PopupMenuItem) {
      return declare([BaseWidget], {
          baseClass: 'jimu-widget-FeatureSelection',
          ToolBar: null,
          Bufferdistance:null,
          LayerTotObj: [],
          ExportData:[],
          treeArray: [],
          CSVdatarow : [],
          BufferData: [],
          Treestore: [],
          DisplayattrObj: [],
          relatedidObj: [],
          InitialExtent: [],
          getSelectedAttrObj: null,
          templateString: template,
          postCreate: function () {
              this.inherited(arguments);
              var currentWidget = this;
              currentWidget.ToolBar = new Draw(currentWidget.wabWidget.map);
              currentWidget.ToolBar.on("draw-end", lang.hitch(currentWidget, currentWidget.ExecuteQueryTask));
              ///For map graphics to features
              var selectionColor = new Color("#00FFFF");
              this.defaultPointSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.STYLE_CIRCLE,
                  16, null, selectionColor);
              this.defaultLineSymbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                  selectionColor, 2);
              this.defaultFillSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                  this.defaultLineSymbol,
                  new Color([selectionColor.r, selectionColor.g, selectionColor.b, 0.3]));
          },
          startup: function () {
              domStyle.set(dom.byId('QueryLoader'), "display", "block");
              var currentWidget = this;
              console.log("feature selections", currentWidget.wabWidget.LayerTotObj);
              if (currentWidget.wabWidget.LayerTotObj != null) {
                  currentWidget.LayerTotObj = currentWidget.wabWidget.LayerTotObj;
              }
              on(dom.byId(currentWidget.Drawextent), "click", function () {
                  currentWidget.ToolBar.activate(Draw.EXTENT)
              });
          },
          ExecuteQueryTask: function (evt) {
              domStyle.set(dom.byId('content'), "display", "none");
              domStyle.set(dom.byId('QueryLoader'), "display", "block");
              domStyle.set(dom.byId('AttributeFinder'), "display", "none");
              dojo.empty("AttrTableid");
              dojo.empty("treeContainer");
             // dojo.byId("resultCount").innerText = "";
             // dojo.byId("Relations_Count").innerText = "";
              var currentWidget = this;
              var queryList = [];
              var queryTaskList = [];
              count = 0;
              for (var i = 0; i < currentWidget.LayerTotObj.length; i++) {
                  var query = new Query();
                  var queryTask = new QueryTask(currentWidget.LayerTotObj[i].url);
                  query.outSpatialReference = currentWidget.wabWidget.map.spatialReference;
                  query.geometry = evt.geometry;
                  query.returnGeometry = true;
                  query.outFields = ["*"];
                  queryTaskList.push(queryTask);
                  queryList.push(query);
              }
              var defTasks = dojo.map(queryTaskList, function (task) {
                  return new dojo.Deferred();
              }); //map each query task to a new dojo.Deferred

              var dlTasks = new dojo.DeferredList(defTasks); //And use all of these Deferreds in a DeferredList  
              dlTasks.then(function (queryResults) {
                  var ln = queryResults.length;
                  for (k = 0; k < ln; k++) {
                      if (queryResults[k][0] == false) {
                          console.log(queryResults[k][1], queryTaskList[k].url, "Spatial Query", new Date().toLocaleString(), "Error");
                          queryResults.splice(k, 1);
                          currentWidget.LayerTotObj.splice(k, 1);
                          ln = ln - 1;
                          k = k - 1;
                      }
                  }
                  currentWidget.handleQueryResults(queryResults);
              }, function (error) {
                  console.log(error);
              });
              for (p = 0; p < queryTaskList.length; p++) { //Use 'for' instead of 'for...in' so you can sync tasks with defTasks  
                  try {
                      queryTaskList[p].execute(queryList[p], defTasks[p].callback, defTasks[p].errback); //Execute each task  
                  } catch (e) {
                      console.log(e);
                      defTasks[p].errback(e); //If you get an error for any task, execute the errback  
                  }
              }
          },
          handleQueryResults: function (results) {
              var currentWidget = this;
              var geometry, symbol;
              currentWidget.wabWidget.map.graphics.clear();
              currentWidget.treeArray = [];
              currentWidget.DisplayattrObj = [];
              currentWidget.relatedidObj = [];
              var geomtryarray = [];
              var resultsFlag = true;
              currentWidget.treeArray.push({ id: "Parentgroup", name: "Results" })
              if (results.length == currentWidget.LayerTotObj.length) {
                  for (var i = 0; i < results.length; i++) {
                      if (results[i][1].features.length > 0) {
                          resultsFlag = false;
                          var layerparent = { id: currentWidget.LayerTotObj[i].name, name: currentWidget.LayerTotObj[i].name, parent: "Parentgroup" }
                          if (currentWidget.LayerTotObj[i]["isrelationsExist"] == false)
                              currentWidget.treeArray.push(layerparent);
                          geomtryarray.push({ name: currentWidget.LayerTotObj[i].name, geomtryType: results[i][1].geometryType });
                          if (results[i][1].geometryType === "esriGeometryPoint") {
                              symbol = this.defaultPointSymbol;
                          } else if (results[i][1].geometryType === "esriGeometryLine" || results[i][1].geometryType === "esriGeometryPolyline") {
                              symbol = this.defaultLineSymbol;
                          }
                          else {
                              symbol = this.defaultFillSymbol;
                          }
                          var displayname;
                          if (typeof (results[i][1].displayFieldName) != "undefined" || typeof (results[i][1].DISPLAYFIELDNAME) != "undefined") {
                              displayname = results[i][1].displayFieldName || results[i][1].DISPLAYFIELDNAME;
                          }
                          else {
                              displayname = results[i][1].objectIdFieldName;
                          }
                          var primaryKeyColumn = "";
                          for (var x = 0; x < results[i][1].fields.length; x++) {
                              if (results[i][1].fields[x].type == "esriFieldTypeOID") {
                                  primaryKeyColumn = results[i][1].fields[x].name;
                                  break;
                              }
                          }
                          for (var j = 0; j < results[i][1].features.length; j++) {
                              geometry = results[i][1].features[j].geometry;
                              currentWidget.wabWidget.map.graphics.add(new Graphic(geometry, symbol));
                              var displayField = results[i][1].features[j].attributes[primaryKeyColumn]; //results[i].features[j].attributes.OBJECTID || results[i].features[j].attributes.objectid
                              var displayfieldObj = { id: currentWidget.LayerTotObj[i].name + displayField, name: displayname + ":" + displayField, parentname: "OBJECTID:" + displayField, parent: currentWidget.LayerTotObj[i].name, Name: currentWidget.LayerTotObj[i].name, attributes: results[i][1].features[j].attributes, fields: currentWidget.LayerTotObj[i].fields, typeIdField: currentWidget.LayerTotObj[i].typeIdField, "domainValues": currentWidget.LayerTotObj[i].domaintypes };
                              var Dataobject = { name: "OBJECTID:" + displayField, attr: results[i][1].features[j], geomtype: results[i][1].geometryType, layername: currentWidget.LayerTotObj[i].name, Fields: currentWidget.LayerTotObj[i].fields };
                              currentWidget.DisplayattrObj.push(Dataobject);
                              if (currentWidget.LayerTotObj[i]["relations"] != undefined || currentWidget.LayerTotObj[i]["relations"] != null) {
                                  if (currentWidget.LayerTotObj[i]["type"] == "Feature Layer") {
                                      currentWidget.relatedidObj = currentWidget.LayerTotObj[i].relations;
                                      for (var k = 0; k < currentWidget.LayerTotObj[i].relations.length; k++) {
                                          var displayrelationObj = { objectId: displayField, id: currentWidget.LayerTotObj[i].relations[k].name + displayField, name: currentWidget.LayerTotObj[i].relations[k].name, parent: currentWidget.LayerTotObj[i].name + displayField, layername: currentWidget.LayerTotObj[i].name, hasrelationship: true, fields: currentWidget.LayerTotObj[i].fields }
                                          currentWidget.treeArray.push(displayrelationObj);
                                      }
                                  }
                              }
                              if (currentWidget.LayerTotObj[i]["isrelationsExist"] == false)
                                  currentWidget.treeArray.push(displayfieldObj);
                          }
                      }
                  }
                  if (resultsFlag) {
                      currentWidget.popAlert("no results found");
                      currentWidget.ToolBar.deactivate();
                      domStyle.set(dom.byId('QueryLoader'), "display", "none");
                      return;
                  }
                  domStyle.set(dom.byId('AttributeFinder'), "display", "block");
                 // domStyle.set(dom.byId('AttributeInfotab'), "display", "none");
                  //document.getElementById("selectedLayer").selectedIndex = 0;
                  //document.getElementById("Static_Img").style.display = "none";
                  currentWidget.buildTree(currentWidget.treeArray, geomtryarray,"Featureselection")
              }
              else {
                  currentWidget.popAlert("no results found");
                  currentWidget.ToolBar.deactivate();
                  domStyle.set(dom.byId('QueryLoader'), "display", "none");
                  return;
              }
          },
          popAlert: function (message) {
              new Message({
                  titleLabel: "Attribute Query",
                  message: message
              });
          },

          buildTree: function (array, geomtryarray,type) {
              try {                 
                  var currentWidget = this;
                  currentWidget.ExportData = array;
                  var Relations = [];
                  currentWidget.Treestore = null;
                  var treeId = "";
                  if (type == "SearchValue") {
                      currentWidget.DisplayattrObj=currentWidget.wabWidget.AttributerelationTab.DisplayattrObj;
                  }
                  currentWidget.Treestore = new Memory({
                      data: array,
                      getChildren: function (object) {
                          return this.query({ parent: object.id });
                      }
                  });
                  treeId = "Parentgroup";
                  isShowRoot = false;
                  currentWidget.Treestore = new Observable(currentWidget.Treestore);
                  var treeModel = new ObjectStoreModel({
                      store: currentWidget.Treestore,
                      query: { id: treeId }
                  });
                  var AttributTree = dijit.byId("SelectFeat");
                  if (AttributTree) {
                      AttributTree.destroyRecursive();
                  }
                  for (var i = 0; i < geomtryarray.length; i++) {
                      if (geomtryarray[i].geomtryType == undefined) {
                          Relations.push(geomtryarray[i]);
                      }
                  }
                 // dojo.byId("resultCount").innerText = geomtryarray.length;
                  if (Relations.length > 0) {
                     // dojo.byId("Relations_Count").innerText = Relations.length;

                  }
                  var Attrtree = new dijit.Tree({
                      model: treeModel,
                      id: "SelectFeat",
                      showRoot: isShowRoot,
                      onClick: function (item, node, event) {
                          currentWidget.getSelectedAttrObj = null;
                         // domStyle.set(dom.byId('AttributeInfotab'), "display", "block");
                          if (item["parentname"] != undefined) {
                              if (item.parentname.includes("objectid") || item.parentname.includes("OBJECTID")) {
                                  menu.bindDomNode(Attrtree.domNode);
                                  currentWidget.getSelectedAttrObj = item.parentname;
                                  currentWidget.getSelectedparentObj = item.parent;
                                  currentWidget.buildAttributesTableSelection(item);
                                  //resizeY(e.pageY + 25);
                                  // currentWidget.resizer(11, mousemove, cursor);
                              }
                              else {
                                  menu.unBindDomNode(Attrtree.domNode);
                                  dojo.empty("AttrTableid");
                              }
                          }
                          else {
                              menu.unBindDomNode(Attrtree.domNode);
                              dojo.empty("AttrTableid");
                          }
                      },
                      onOpen: function (item, node) {
                          if (item.hasrelationship != undefined || item.hasrelationship != null) {
                              domStyle.set(dom.byId('AttributeFinder'), "display", "block");
                              domStyle.set(dom.byId('QueryLoader'), "display", "block");
                              var id = "#" + node.id;
                              var relationTablearray = [];
                              var reltionurl = "";
                              var LayerObj = currentWidget.LayerTotObj.find(x => x.name === item.layername);
                              var nodevalue = item.objectId;
                              var parentId = item.id;
                              var nameId = item.name + nodevalue + "_";
                              for (var j = 0; j < LayerObj.relations.length; j++) {
                                  if (LayerObj.relations[j].name == item.name) {
                                      relationId = LayerObj.relations[j].id;
                                      relationshipTableName = LayerObj.relations[j].relatedTableId;
                                      var str = LayerObj.url;
                                      var n = str.lastIndexOf('/');
                                      var reltionurl = str.substring(0, n + 1) + LayerObj.relations[j].relatedTableId;
                                      break;
                                  }
                              }
                              var parentlayer = new FeatureLayer(LayerObj.url);
                              var relatedQuery = new RelationshipQuery();
                              relatedQuery.outFields = ["*"];
                              relatedQuery.relationshipId = relationId;
                              relatedQuery.objectIds = [nodevalue];
                              relatedQuery.returnGeometry = true;
                              relatedQuery.outSpatialReference = currentWidget.wabWidget.map.spatialReference;
                              parentlayer.queryRelatedFeatures(relatedQuery, function (relatedRecords) {
                                  var result = relatedRecords;
                                  if (result[nodevalue] != undefined || result[nodevalue] != null) {
                                      var relationshipGeometry = result[nodevalue].geometryType;
                                      var resultcount = result[nodevalue].features.length;
                                      for (var k = 0; k < resultcount; k++) {
                                          var featureAttributes = result[nodevalue].features[k].attributes;
                                          var displayField = result[nodevalue].features[k].attributes.OBJECTID || result[nodevalue].features[k].attributes.objectid;
                                          var fields = currentWidget.LayerTotObj.find(x => x.url == reltionurl)
                                          var displafieldId = { id: nameId + displayField, name: "OBJECTID:" + displayField, parentname: "OBJECTID:" + displayField, parent: parentId, "attributes": featureAttributes, "fields": fields.fields, "typeIdField": fields.typeIdField, "domainValues": fields.domaintypes };
                                          relationTablearray.push(displafieldId)
                                          var displayrelationobject = { name: "OBJECTID:" + displayField, attr: result[nodevalue].features[k], geomtype: result[nodevalue].geometryType, layername: parentId, id: displayField };
                                          currentWidget.DisplayattrObj.push(displayrelationobject);
                                      }
                                      currentWidget.relationTabletreeSpatialData(relationTablearray, id, relationshipGeometry);
                                  }
                                  else {
                                      domStyle.set(dom.byId('QueryLoader'), "display", "none");
                                      return;
                                  }
                              });
                          };
                          if (item["parentname"] != undefined) {
                              if (item.parentname.includes("objectid") || item.parentname.includes("OBJECTID")) {
                                  dojo.query("#treeContainer> div > div > div > div > div > div > div > div > div > div >.dijitTreeExpando").addClass('relatioShipFeature');
                              }
                          }
                          if (item["parent"] != undefined) {
                              if (item.parent === "Parentgroup") {
                                  for (var i = 0; i < geomtryarray.length; i++) {
                                      if (item.name === geomtryarray[i].name) {

                                          if (geomtryarray[i].geomtryType === "esriGeometryPoint") {
                                              dojo.query("#treeContainer > div > div > div > div > div > div > div > div > .dijitTreeExpando").addClass('Pointfeatures');
                                          }
                                          else if (geomtryarray[i].geomtryType === "esriGeometryPolygon") {
                                              dojo.query("#treeContainer > div > div > div > div > div > div > div > div > .dijitTreeExpando").addClass('polygonFeature');
                                          }
                                          else {
                                              dojo.query("#treeContainer > div > div > div > div > div > div > div > div > .dijitTreeExpando").addClass('linefeature');
                                          }
                                          break;
                                      }
                                  }
                              }
                          }
                      }
                  }).placeAt("treeContainer");

                  var menu = new Menu();
                  menu.addChild(new MenuItem({
                      label: "Zoom To Location",
                      onClick: function () {
                          currentWidget.ZoomtoLocation(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj, "Zoom");
                      }
                  }));

                  menu.addChild(new dijit.MenuItem({
                      label: "Pan To",
                      onClick: function () {
                          currentWidget.buildPanToQuery(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj);
                      }
                  }));

                  menu.addChild(new dijit.MenuItem({
                      label: "Highlight",
                      onClick: function () {
                          currentWidget.buildHighlightQuery(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj);
                      }
                  }));
                  menu.addChild(new dijit.MenuItem({
                      label: "Select",
                      onClick: function () {
                          currentWidget.ZoomtoLocation(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj,"Select");
                      }
                  }));
                  menu.addChild(new dijit.MenuItem({
                      label: "Buffer",
                      onClick: function () {
                          currentWidget.buildBuffer(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj);
                      }
                  }));
                  menu.addChild(new dijit.MenuItem({
                      label: "Spatial Query",
                      onClick: function () {
                          currentWidget.buildSpacialQuery(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj);
                      }
                  }));
                  menu.addChild(new dijit.MenuItem({
                      label: "Document Links",
                      onClick: function () {
                          currentWidget.buildDocumentLinks(currentWidget.getSelectedAttrObj, currentWidget.getSelectedparentObj);
                      }
                  }));
                  menu.startup();
                  domStyle.set(dom.byId('QueryLoader'), "display", "none");
                  currentWidget.ToolBar.deactivate();
              }
              catch (e) {
                  domStyle.set(dom.byId('QueryLoader'), "display", "none");
                  console.log(e.message);
                  return;
              }
          },
          relationTabletreeSpatialData: function (data, id, relationshipGeometry) {
              try {
                  var currentWidget = this;
                  for (var i = 0; i < data.length; i++) {
                      currentWidget.Treestore.add(data[i]);
                  }
                  domStyle.set(dom.byId('QueryLoader'), "display", "none");
                  if (relationshipGeometry === undefined) {
                      dojo.query(id + " " + "div div div .dijitTreeExpando").addClass('Pointfeatures');
                  }
                  else if (relationshipGeometry === "esriGeometryPoint") {
                      dojo.query(id + " " + "div div div .dijitTreeExpando").addClass('Pointfeatures');
                  }
                  else if (relationshipGeometry === "esriGeometryPolygon") {
                      dojo.query(id + " " + "div div div .dijitTreeExpando").addClass('polygonFeature');
                  }
                  else {
                      dojo.query(id + " " + "div div div .dijitTreeExpando").addClass('linefeature');
                  }
              }
              catch (e) {
                  domStyle.set(dom.byId('QueryLoader'), "display", "none");
              }
          },
          /// /////////// End For on map draw extention data////
          buildAttributesTableSelection: function (data) {
              try {
                  var featureAttributes, tbody;
                  var table = query(".Attrtable");
                  dojo.empty("AttrTableid");
                  tbody = '<tbody class="FeaturesBody" id="tbodyid123">'
                  if (data.fields != null) {
                      featureAttributes = data.attributes;
                      for (var T = 0; T < data.fields.length; T++) {
                          if (data.fields[T].type == "esriFieldTypeGeometry ")
                              continue;
                          if (data.fields[T].name.toUpperCase() == "SHAPE")
                              continue;
                          if (data.fields[T].type == "esriFieldTypeDate") {
                              featureAttributes[data.fields[T].name] = dojo.date.locale.format(new Date(featureAttributes[data.fields[T].name]), { datePattern: "MM/dd/yyyy" });
                              tbody = tbody + '<tr> <td>' + data.fields[T].alias + '</td>';
                              tbody = tbody + '<td>' + featureAttributes[data.fields[T].name] + '</td></tr>';
                          }
                          else if (data.fields[T].name == data.typeIdField) {
                              var domainVal = data.domainValues.find(x => x.id == featureAttributes[data.fields[T].name]);
                              tbody = tbody + '<tr> <td>' + data.fields[T].alias + '</td>';
                              if (domainVal == undefined) {
                                  tbody = tbody + '<td>' + featureAttributes[data.fields[T].name] + '</td></tr>';
                              } else {
                                  tbody = tbody + '<td>' + domainVal.name + '</td></tr>';
                              }
                          }
                          else if (data.fields[T].domain != null) {
                              if (data.fields[T].domain.codedValues != undefined) {
                                  for (var d = 0; d < data.fields[T].domain.codedValues.length; d++) {
                                      if (featureAttributes[data.fields[T].name] || featureAttributes[data.fields[T].name] > -1) {
                                          if (data.fields[T].domain.codedValues[d].code == featureAttributes[data.fields[T].name])
                                              featureAttributes[data.fields[T].name] = data.fields[T].domain.codedValues[d].name;
                                      }
                                  }
                              }
                              tbody = tbody + '<tr> <td>' + data.fields[T].alias + '</td>';
                              tbody = tbody + '<td>' + featureAttributes[data.fields[T].name] + '</td></tr>';
                          }
                          else {
                              tbody = tbody + '<tr> <td>' + data.fields[T].alias + '</td>';
                              tbody = tbody + '<td>' + featureAttributes[data.fields[T].name] + '</td></tr>';
                          }
                      }
                      tbody = tbody + '</tbody>';
                  }
                  table.append(tbody);
              }
              catch (e) {
                  console.log(e)
              }
          },
          clearTree: function () {
              try {
                  var currentWidget = this;
                  domStyle.set(dom.byId('AttributeFinder'), "display", "block");
                  dojo.empty("AttrTableid");
                  dojo.empty("treeContainer");
                  domStyle.set(dom.byId('content'), "display", "none");
                  query(".gridtable .fieldsBody").style("display", "none");
                  //document.getElementById("selectedLayer").selectedIndex = 0;
                  var AttributTree = dijit.byId("SelectFeat");
                  if (AttributTree) {
                      AttributTree.destroyRecursive();
                  }
                  currentWidget.ExportData = [];
                 // dojo.byId("resultCount").innerText = "";
                 // dojo.byId("Relations_Count").innerText = "";
                  currentWidget.wabWidget.map.setExtent(currentWidget.wabWidget.InitialExtent);
                  currentWidget.wabWidget.clearTree();
                  // currentWidget.map.graphics.clear();
                  currentWidget.wabWidget.AttributerelationTab.OnFeatureChange();
              }
              catch (e) {
                  console.log(e);
              }
          },
          ///////Zoom to selected feature///
          ZoomtoLocation: function (data,LayerName,Type) {
              try {
                  var currentWidget = this;
                  var geometry, symbol, lat, long;
                  currentWidget.wabWidget.map.graphics.clear();
                  var markersymbol = new SimpleMarkerSymbol();
                  markersymbol.setColor(new Color("#00e600")); //point graphics
                  var fillsymbol = new SimpleFillSymbol("solid", null, new Color([77, 77, 255, 0.75]));//polygon graphics
                  var linesymbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([255, 51, 153]), 4.0);//line graphics
                  for (var i = 0; i < currentWidget.DisplayattrObj.length; i++) {
                      if (data == currentWidget.DisplayattrObj[i].name) {
                          geometry = currentWidget.DisplayattrObj[i].attr.geometry;
                          if (geometry == undefined) {
                              lat = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LATITUDE);
                              long = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LONGITUDE);
                              geometry = new Point(long, lat);
                              symbol = markersymbol
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 12);
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPoint") {
                              //currentWidget.wabWidget.map.centerAndZoom(geometry, 12);
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 18);
                              symbol = this.defaultPointSymbol;
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPolygon") {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = this.defaultFillSymbol;
                          }
                          else {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = this.defaultLineSymbol;//this.defaultPointSymbol;
                             
                          }
                          break;
                      }
                  };
                  if (Type == "Select") {
                      currentWidget.wabWidget.map.graphics.add(new Graphic(geometry, symbol));
                  }
              }
              catch (e) {
                  console.log(e);
              }
          },
          ///////Pan to for feature///
          buildPanToQuery: function (data) {
              try {
                  var currentWidget = this;
                  var geometry, symbol, lat, long;
                  currentWidget.wabWidget.map.graphics.clear();
                  var markersymbol = new SimpleMarkerSymbol();
                  markersymbol.setColor(new Color("#00e600")); //point graphics
                  var fillsymbol = new SimpleFillSymbol("solid", null, new Color([77, 77, 255, 0.75]));//polygon graphics
                  var linesymbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([255, 51, 153]), 4.0);//line graphics
                  for (var i = 0; i < currentWidget.DisplayattrObj.length; i++) {
                      if (data == currentWidget.DisplayattrObj[i].name) {
                          geometry = currentWidget.DisplayattrObj[i].attr.geometry;
                          if (geometry == undefined) {
                              lat = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LATITUDE);
                              long = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LONGITUDE);
                              geometry = new Point(long, lat);
                              symbol = markersymbol
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 12);
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPoint") {
                              //currentWidget.wabWidget.map.centerAndZoom(geometry, 12);
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 20);
                              symbol = markersymbol;
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPolygon") {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = fillsymbol;
                          }
                          else {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = linesymbol;
                          }
                          break;
                      }
                  };
                  //currentWidget.wabWidget.map.graphics.add(new Graphic(geometry, symbol));
              }
              catch (e) {
                  console.log(e);
              }
          },

          ////////feature Highlight Query////////////
          buildHighlightQuery: function (data) {

              try {
                  var currentWidget = this;
                  var geometry, symbol, lat, long;
                  var HighlatedPoint = new PictureMarkerSymbol({
                      "url": "../6/widgets/AttributeRelationShip/images/point.gif",
                      "height": 40,
                      "width": 40,
                      "border": 0,
                      "draggable": false,
                      "margin": 0,
                      "opacity": 3,
                      "type": "esriPMS"
                  });
                  var HighlatedLine = new PictureMarkerSymbol({
                      "url": "../6/widgets/AttributeRelationShip/images/line.gif",
                      "height": 50,
                      "width": 50,
                      "border": 0,
                      "draggable": false,
                      "margin": 0,
                      "opacity": 3,
                      "type": "esriPMS"
                  });
                  var HighlatedPolygon = new PictureMarkerSymbol({
                      "url": "../6/widgets/AttributeRelationShip/images/shape.gif",
                      "height": 50,
                      "width": 50,
                      "border": 0,
                      "draggable": false,
                      "margin": 0,
                      "opacity": 3,
                      "type": "esriPMS"
                  });

                  currentWidget.wabWidget.map.graphics.clear();
                  //var Highlated = new SimpleMarkerSymbol(SimpleMarkerSymbol.STYLE_CIRCLE, 12, new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                  //new Color([210, 105, 30, 0.5]), 8), new Color([210, 105, 30, 0.9]));
                  var markersymbol = new SimpleMarkerSymbol();
                  markersymbol.setColor(new Color("#00e600")); //point graphics
                  var fillsymbol = new SimpleFillSymbol("solid", null, new Color([77, 77, 255, 0.75]));//polygon graphics
                  var linesymbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([255, 51, 153]), 4.0);//line graphics
                  for (var i = 0; i < currentWidget.DisplayattrObj.length; i++) {
                      if (data == currentWidget.DisplayattrObj[i].name) {
                          geometry = currentWidget.DisplayattrObj[i].attr.geometry;
                          if (geometry == undefined) {
                              lat = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LATITUDE);
                              long = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LONGITUDE);
                              geometry = new Point(long, lat);
                              symbol = markersymbol
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 12);
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPoint") {
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 18);
                              symbol = HighlatedPoint;
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPolygon") {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = HighlatedPolygon;
                          }
                          else {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = HighlatedLine;
                          }
                          break;
                      }
                  };                 
                  currentWidget.wabWidget.map.graphics.add(new Graphic(geometry, symbol));
              
              }
              catch (e) {
                  console.log(e);
              }

          },         

          //////Apply buffer to selected Feature/////
          buildBuffer: function (data) {
              try {
                  var modal = document.getElementById("myModal");
                  var btn = document.getElementById("myBtn");
                  var span = document.getElementsByClassName("close")[0];
                  modal.style.display = "block";                 
                  var currentWidget = this;
                 // currentWidget.Bufferdistance = "";
                  var geometry, symbol, lat, long;
                  currentWidget.wabWidget.map.graphics.clear();
                  var markersymbol = new SimpleMarkerSymbol();
                  markersymbol.setColor(new Color("#00e600")); //point graphics
                  var fillsymbol = new SimpleFillSymbol("solid", null, new Color([77, 77, 255, 0.75]));//polygon graphics
                  var linesymbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([255, 51, 153]), 4.0);//line graphics
                  for (var i = 0; i < currentWidget.DisplayattrObj.length; i++) {
                      if (data == currentWidget.DisplayattrObj[i].name) {
                          geometry = currentWidget.DisplayattrObj[i].attr.geometry;
                          if (geometry == undefined) {
                              lat = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LATITUDE);
                              long = JSON.parse(currentWidget.DisplayattrObj[i].attr.attributes.LONGITUDE);
                              geometry = new Point(long, lat);
                              symbol = markersymbol
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 20);
                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPoint") {
                              currentWidget.wabWidget.map.centerAndZoom(geometry, 20);
                              symbol = markersymbol;
                              currentWidget.Bufferdistance = geometry;

                          }
                          else if (currentWidget.DisplayattrObj[i].geomtype === "esriGeometryPolygon") {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = fillsymbol;
                              currentWidget.Bufferdistance = geometry;

                          }
                          else {
                              var extentLocation = geometry.getExtent();
                              currentWidget.wabWidget.map.setExtent(extentLocation.expand(1.2), true);
                              symbol = linesymbol;
                              currentWidget.Bufferdistance = geometry;

                          }
                      }
                  };
                  currentWidget.wabWidget.map.graphics.add(new Graphic(geometry, symbol));
              }
              catch (e) {
                  console.log(e);
              }
              SpanCancel.onclick = function () {
                  modal.style.display = "none";
              }             
              //on(dom.byId("execute"), "click", function () {                 
              //});
          },
          ApplyBuffer: function () {
              var currentWidget = this;
              esriConfig.defaults.geometryService = new GeometryService("https://utility.arcgisonline.com/ArcGIS/rest/services/Geometry/GeometryServer");
              esriConfig.defaults.io.proxyUrl = "/proxy/";
              esriConfig.defaults.io.alwaysUseProxy = false;
              var params = new BufferParameters();
              params.distances = [dom.byId("distance").value];
              if (dom.byId("distance").value != "") {
                  params.outSpatialReference = map.spatialReference;
                  params.unit = GeometryService[dom.byId("unit").value];
                  normalizeUtils.normalizeCentralMeridian([currentWidget.Bufferdistance]).then(function (normalizedGeometries) {
                      var normalizedGeometry = normalizedGeometries[0];
                      if (normalizedGeometry.type === "polygon") {
                          //if geometry is a polygon then simplify polygon.  This will make the user drawn polygon topologically correct.
                          esriConfig.defaults.geometryService.simplify([normalizedGeometry], function (geometries) {
                              params.geometries = geometries;
                              esriConfig.defaults.geometryService.buffer(params, showBuffer);
                          });
                      } else {
                          params.geometries = [normalizedGeometry];
                          esriConfig.defaults.geometryService.buffer(params, showBuffer);
                      }
                  });
                  domStyle.set(dom.byId('myModal'), "display", "none");
                  function showBuffer(bufferedGeometries) {
                      var symbol = new SimpleFillSymbol(
                          SimpleFillSymbol.STYLE_SOLID,
                          new SimpleLineSymbol(
                              SimpleLineSymbol.STYLE_SOLID,
                              new Color([255, 0, 0, 0.65]), 2),
                          new Color([255, 0, 0, 0.35])
                      );
                      array.forEach(bufferedGeometries, function (geometry) {
                          var graphic = new Graphic(geometry, symbol);
                          this._widgetManager.map.graphics.add(graphic);
                      });
                  }
              } else {
                  alert("Please Enter Buffer Distance");
              }
          },
          ClearValues: function () {
              document.getElementById("distance").value = "";
          },


          //////Exporting options///////
          ///CSV///
          //ExportToData: function () {
          //    try{
          //        var currentWidget = this;                
          //        var row = "";var CSV=''; var datarow = [];
          //        CSV += "Attribute_Relation_Data" + '\r\n\n';
          //            for (var csv = 0; csv < currentWidget.ExportData.length; csv++) {                    
          //                for (var index in currentWidget.ExportData[csv].attributes) {                           
          //                    row += index + ',';                             
          //                }
          //                row = row.slice(0, -1);
          //                CSV += row + '\r\n';
          //                datarow.push({ LayerName: currentWidget.ExportData[csv].Name, Row: row, CSVRow: CSV });
          //            }                
          //            currentWidget.CSVdatarow = datarow.reduce((unique, o) => {
          //                if (!unique.some(obj => obj.LayerName === o.LayerName)) {
          //                    unique.push(o);
          //                }
          //                return unique;
          //            }, []);
          //            console.log(currentWidget.CSVdatarow);
          //        currentWidget.JSONToCSVConvertor(currentWidget.ExportData, "Attribute_Relation_Data", true);
          //    } catch (e) {
          //        console.log(e);
          //    }        

          //},

          //JSONToCSVConvertor: function (JSONData, ReportTitle, ShowLabel) {           
          //    var arrData = [];
          //    var currentWidget = this;
          //    var CSV = '';
          //    var link = "";                        
          //        for (i = 0; i < JSONData.length; i++) {
          //            //if( JSONData[i].Name = JSONData[i].parent&&)                    
          //            if (JSONData[i].attributes != undefined) {                          
          //                //LayerNameofCSV = LayerName.Name;                          
          //                    arrData1 = typeof JSONData[i].attributes != 'object' ? JSON.parse(JSONData[i].attributes) : JSONData[i].attributes;
          //                    arrData.push(arrData1);                         
          //            }                     
          //        }             
          //     CSV += ReportTitle + '\r\n\n';
          //    ////This condition will generate the Label/Header
          //    if (ShowLabel) {
          //        var row = "";
          //        //This loop will extract the label from 1st index of on array                  
          //        for (var index in arrData[0]) {
          //            //Now convert each value to string and comma-seprated
          //            row += index + ',';
          //        }              
          //        row = row.slice(0, -1);
          //        //append Label row with line break
          //        CSV += row + '\r\n';
          //    }
          //    if (JSONData.length > 0) {
          //        //1st loop is to extract each row
          //        //CSV += currentWidget.CSVdatarow[4].CSVRow + '\r\n';

          //        for (var i = 0; i < JSONData.length; i++) {
          //            for (var d = 0; d < currentWidget.CSVdatarow.length; d++) {
          //                //var row = "";
          //                //CSV += currentWidget.CSVdatarow[d].CSVRow + '\r\n';
          //                if (currentWidget.CSVdatarow[d].LayerName == JSONData[i].Name && currentWidget.CSVdatarow[d].LayerName != undefined && JSONData[i].Name!=undefined) {
          //                    var row = "";
          //                    for (var index in JSONData[i].attributes) {
          //                        row += '"' + JSONData[i].attributes[index] + '",';
          //                    }
          //                    row.slice(0, row.length - 1);
          //                    CSV += row + '\r\n';
          //                }
          //            }
          //            //var LayerName = currentWidget.CSVdatarow.find(x => x.LayerName === JSONData[i].Name);
          //            //if (LayerName == JSONData[i].Name) {
          //            //    var row = "";
          //            //    for (var index in JSONData[i].attributes) {
          //            //        row += '"' + JSONData[i].attributes[index] + '",';
          //            //    }
          //            //    row.slice(0, row.length - 1);
          //            //    CSV += row + '\r\n';
          //                //} else {
          //                //    var row = "";
          //                //  //This loop will extract the label from 1st index of on array
          //                //    for (var index in arrData[i]) {
          //                //        //Now convert each value to string and comma-seprated
          //                //        row += index + ',';
          //                //    }
          //                //    row = row.slice(0, -1);
          //                //    //append Label row with line break
          //                //    CSV += row + '\r\n';
          //                //    for (var i = 0; i < arrData.length; i++) {
          //                //        var row = "";
          //                //        for (var index in arrData[i]) {
          //                //            row += '"' + arrData[i][index] + '",';
          //                //        }
          //                //        row.slice(0, row.length - 1);
          //                //        CSV += row + '\r\n';
          //                //    }
          //                //}
          //            //}
          //        }
          //        if (CSV == '') {
          //            alert("Invalid data");
          //            return;
          //        }
          //        //Generate a file name
          //        var fileName = "MyReport_";
          //        //this will remove the blank-spaces from the title and replace it with an underscore
          //        fileName += ReportTitle.replace(/ /g, "_");
          //        //Initialize file format you want csv or xls
          //        var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
          //        link = document.createElement("a");
          //        link.href = uri;
          //        //set the visibility hidden so it will not effect on your web-layout
          //        link.style = "visibility:hidden";
          //        link.download = fileName + ".csv";
          //        //this part will append the anchor tag and remove it after automatic click
          //        document.body.appendChild(link);
          //        link.click();
          //        document.body.removeChild(link);
          //    }
          //    else {
          //        alert("No data found");
          //    }
          //},


      });
  });


