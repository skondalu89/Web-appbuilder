﻿
define({
    root: ({
        _widgetLabel: "AttributeRelationShip",

        noOptionsConfigured: "No options were configured.",

        tabs: {
            search: "Asset Finder",
            url: "Attribute Viewer",
            file: "File"
        },

        search: {
           
        },

        addFromUrl: {
            
        },

        addFromFile: {
           },

        layerList: {
            
        }

    }),
   
});
