///////////////////////////////////////////////////////////////////////////
// Copyright © Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////
define(["dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/aspect",
    "dojo/Deferred", "dojo/dom-style", "dojo/dom", "dojo/query",
    "dojo/dom-class",
    "jimu/portalUrlUtils",
    "jimu/portalUtils",
    "jimu/tokenUtils",
    "jimu/BaseWidget",
    "jimu/dijit/TabContainer3",
    "dijit/_WidgetsInTemplateMixin",
    "./search/AttributeRelationShip",
    "./search/FeatureSelection",
    "esri/request",
    "dojo/_base/array",
    "dojo/request/xhr"
],
  function (declare, lang, on, aspect, Deferred, domStyle, dom, query, domClass, portalUrlUtils, portalUtils,
      tokenUtils, BaseWidget, TabContainer3, _WidgetsInTemplateMixin, AttributeRelationShip, FeatureSelection, esriRequest,
      array, requestXHR) {
      return declare([BaseWidget, _WidgetsInTemplateMixin], {
          name: "AttributeRelationShip",
          baseClass: "jimu-widget-AttributeRelationShip",
          batchGeocoderServers: null,
          isPortal: false,
          _isOpen: false,
          _searchOnOpen: false,
          tabContainer: null,
          AttributeRelationShip: null,
          FeatureSelection: null,
          AttributerelationTab: null,
          FeatureSelectionTab: null,
          LayerTotObj: [],
          WithOutFields: [],
          TotalLayersLength: [],
          array: [],
          postCreate: function () {
              this.inherited(arguments);
          },
          startup: function () {
              if (this._started) {
                  return;
              }
              // let target = document.getElementById('widgets_AttributeRelationShip_Widget_34_panel')
              var className = document.getElementsByClassName("title-label")[0].id = "WidgetDragable";
              var moved_div = document.getElementById('WidgetDragable');
              function onDrag(e) {
                  document.getElementsByClassName("jimu-panel jimu-foldable-dijit jimu-foldable-panel Attribute_Widget")[0].id = "AttributeRelationShipWidgetID";
                  var target = document.getElementById('AttributeRelationShipWidgetID');
                  let originalStyles = window.getComputedStyle(target)
                  target.style.left = parseInt(originalStyles.left) + e.movementX + 'px'
                  target.style.top = parseInt(originalStyles.top) + e.movementY + 'px'
              }
              function onLetGo() {
                  document.removeEventListener('mousemove', onDrag)
                  document.removeEventListener('mouseup', onLetGo)
              }
              function onGrab() {

                  document.addEventListener('mousemove', onDrag)
                  document.addEventListener('mouseup', onLetGo)
              }
              moved_div.addEventListener('mousedown', onGrab);
              
              var self = this, args = arguments;
              this.constructLayerObj();
              this._getUser().then(function (user) {
                  document.getElementsByClassName("jimu-panel jimu-foldable-dijit")[0].className += " Attribute_Widget";
                  self._initTabs();
                  return;
              }).then(function () {
                  self.inherited(args);
                  if (self.tabContainer) {
                      self.tabContainer.startup();
                  } else if (self.AttributerelationTab) {
                      self.AttributerelationTab.startup();
                  } else if (self.FeatureSelectionTab) {
                      self.FeatureSelectionTab.startup();
                  }
                  self.resize();
              }).otherwise(function (error) {
                  console.warn("AttributeRelationShip.startup error:", error);
                  self.inherited(args);
                  self.resize();
              });             
          },         
         
      constructLayerObj: function () {
          try {
              var currentWidget = this;
              currentWidget.InitialExtent = currentWidget.map.extent;
              currentWidget.LayerTotObj = [];
              var layerdetails = currentWidget.map.itemInfo.itemData.operationalLayers;
              var layerUrl = "";
              for (var i = 0; i < layerdetails.length; i++) {
                  if (layerdetails[i].visibility) {
                      var checkLayerExits = null;
                      if (layerdetails[i].url.toUpperCase().indexOf("FEATURESERVER") != -1
                          || layerdetails[i].url.toUpperCase().indexOf("MAPSERVER") != -1) {
                          checkLayerExits = currentWidget.map.getLayer(layerdetails[i].id);
                          if (checkLayerExits.layerInfos.length > 0) {
                              if (currentWidget.map.tables.length > 0) {

                                  for (var tb = 0; tb < currentWidget.map.tables.length; tb++) {
                                      var str = currentWidget.map.tables[tb].url;
                                      var n = str.lastIndexOf('/');
                                      var result = str.substring(n + 1);
                                      checkLayerExits.layerInfos.push({ name: currentWidget.map.tables[tb].title, id: parseInt(result), url: str });
                                  }
                              }
                              for (var j = 0; j < checkLayerExits.layerInfos.length; j++) {
                                  if (typeof (checkLayerExits.layerInfos[j].url) != "undefined")
                                      layerUrl = checkLayerExits.layerInfos[j].url;
                                  else
                                      layerUrl = checkLayerExits.url + "/" + checkLayerExits.layerInfos[j].id;

                                  var obj = { url: layerUrl, name: checkLayerExits.layerInfos[j].name };
                                  currentWidget.array.push(obj);
                                  var requestURL = layerUrl + "?f=json";
                                  var requestHandle = esriRequest({
                                      "url": layerUrl,
                                      "content": {
                                          "f": "json"
                                      },
                                      "callbackParamName": "callback"
                                  }).then(function (response) {
                                      currentWidget.TotalLayersLength.push(response);
                                      if (response.type.toUpperCase() == "FEATURE LAYER" || response.type.toUpperCase() == "TABLE"
                                         || response.type.toUpperCase() == "ANNOTATION SUBLAYER" || response.type.toUpperCase() == "ANNOTATION LAYER" || response.type.toUpperCase() == "GROUP LAYER") {
                                          //if (response.type != null || response.type != undefined) {
                                          for (var k = 0; k < currentWidget.array.length; k++) {
                                              if (currentWidget.array[k].name.trim().toUpperCase().indexOf(response.name.trim().toUpperCase()) != -1) {
                                                  //ssssssif (currentWidget.array[k].name == response.name) {
                                                  if (response.fields != null) {
                                                      var objLayer = currentWidget.LayerTotObj.find(x => x.url == currentWidget.array[k].url);
                                                      if (response.relationships.length > 0) {///response.type == "Feature Layer" &&                                                           
                                                          for (var rt = 0; rt < response.relationships.length; rt++) {
                                                              var str = currentWidget.array[k].url;
                                                              var n = str.lastIndexOf('/');
                                                              var Url = str.substring(0, n + 1) + response.relationships[rt].relatedTableId;
                                                              if (typeof (objLayer) == "undefined")
                                                                  currentWidget.LayerTotObj.push({ name: response.relationships[rt].name, url: Url, isrelationsExist: true });
                                                              else {
                                                                  objLayer["typeIdField"] = response.typeIdField;
                                                                  objLayer["domaintypes"] = response.types;
                                                                  objLayer["fields"] = response.fields;
                                                                  objLayer["type"] = response.type;
                                                              }
                                                          }
                                                      }
                                                      if (objLayer) {
                                                          objLayer["typeIdField"] = response.typeIdField;
                                                          objLayer["domaintypes"] = response.types;
                                                          objLayer["fields"] = response.fields;
                                                          objLayer["type"] = response.type;
                                                      }
                                                      else {
                                                          currentWidget.LayerTotObj.push({ name: response.name, url: currentWidget.array[k].url, fields: response.fields, type: response.type, relations: response.relationships, isrelationsExist: false, typeIdField: response.typeIdField, domaintypes: response.types });
                                                      }
                                                      break;
                                                  }
                                              }
                                          }
                                      }
                                      if (currentWidget.TotalLayersLength.length == currentWidget.array.length) {
                                          currentWidget.AttributerelationTab.loadMapServices(currentWidget.LayerTotObj);
                                      }
                                  });
                              }

                          }
                      }
                  }
              };
              console.log("main widget tot", currentWidget.LayerTotObj);
          }
          catch (e) {
              console.log(e);
          }
      },

      clearTree: function () {
          try {
              var currentWidget = this;
              currentWidget.map.setExtent(currentWidget.InitialExtent);
              currentWidget.map.graphics.clear();

          }
          catch (e) {
              console.log(e);
          }
      },
      _getUser: function () {
          var dfd = new Deferred();
          var portalUrl = this.appConfig.portalUrl;
          if (tokenUtils.userHaveSignInPortal(portalUrl)) {
              portalUtils.getPortal(portalUrl).getUser().then(function (user) {
                  dfd.resolve(user);
              }).otherwise(function (error) {
                  console.warn("AttributeRelationShip._getUser error:", error);
                  dfd.resolve(null);
              });
          } else {
              dfd.resolve(null);
          }
          return dfd;
      },

      _initTabs: function () {
          var config = this.config, tabs = [];

          this.AttributerelationTab = new AttributeRelationShip({
              wabWidget: this
          }, this.AttributeRelation);
          tabs.push({
              title: this.nls.tabs.search,
              content: this.AttributerelationTab.domNode
          });
          this.FeatureSelectionTab = new FeatureSelection({
              wabWidget: this
          }, this.featureselection);
          tabs.push({
              title: this.nls.tabs.url,
              content: this.FeatureSelectionTab.domNode
          });

          var self = this;
          if (tabs.length > 0) {
              this.tabContainer = new TabContainer3({
                  average: true,
                  tabs: tabs
              }, this.tabsNode);
              try {
                  if (tabs.length === 1 && this.tabContainer.controlNode &&
                    this.tabContainer.containerNode) {
                      this.tabContainer.controlNode.style.display = "block";
                      this.tabContainer.containerNode.style.top = "0px";
                  }
              } catch (ex1) { }
              this.own(aspect.after(this.tabContainer, "selectTab", function (title) {
                  if (self.searchPane && title === self.nls.tabs.search) {
                      self.searchPane.resize();
                  }
              }, true));
          } else if (tabs.length === 0) {
              this.tabsNode.appendChild(document.createTextNode(this.nls.noOptionsConfigured));
          }
      },
      _setStatus: function (msg) {
          if (!this.messageNode) {
              return;
          }
          util.setNodeText(this.messageNode, msg);
          this.messageNode.title = msg;
      },

      onClose: function () {
          this._isOpen = false;
      },

      onOpen: function () {
          var bSearch = (this.searchPane && this._searchOnOpen);
          this._isOpen = true;
          this._searchOnOpen = false;
          this.resize();
          if (bSearch) {
              this.searchPane.search();
          }
      },
      resize: function () {
          var widgetWidth = this.domNode.clientWidth,
              widgetHeight = this.domNode.clientHeight;
          if (widgetWidth > 1000) {
              domClass.remove(this.domNode, "width-768");
              domClass.add(this.domNode, "width-1200");
          } else if (widgetWidth > 768) {
              domClass.remove(this.domNode, "width-1200");
              domClass.add(this.domNode, "width-768");
          } else {
              domClass.remove(this.domNode, ["width-768", "width-1200"]);
          }

          if (widgetWidth < 420) {
              domClass.remove(this.domNode, "width-medium");
              domClass.add(this.domNode, "width-small");
          } else if (widgetWidth < 750) {
              domClass.remove(this.domNode, "width-small");
              domClass.add(this.domNode, "width-medium");
          } else {
              domClass.remove(this.domNode, ["width-small", "width-medium"]);
          }

          if (widgetWidth < 340) {
              domClass.add(this.domNode, "filter-placeholder-on");
          } else {
              domClass.remove(this.domNode, "filter-placeholder-on");
          }

          if (widgetHeight < 400) {
              domClass.add(this.domNode, "height-small");
          } else {
              domClass.remove(this.domNode, "height-small");
          }

          if (this.searchPane) {
              this.searchPane.resize();
          }
      },
      });

});
